﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Web.BLValidation;
using Web.DataAccess.Data.Repository;
using Web.DataAccess.Data.Repository.IRepository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PdfExtractionController : ControllerBase
    {
        // GET: api/<PdfExtractionController>

        PdfInputfile pdfInputfile = new PdfInputfile();
        private readonly IWebHostEnvironment environment;
        private readonly IUnitOfWork _unitOfWork;
        public PdfExtractionController(IWebHostEnvironment environment, IUnitOfWork unitOfWork)
        {
            this.environment = environment;
            _unitOfWork = unitOfWork;
        }
        [HttpPost]
        [Route("upload")]
        public async Task Post()
        {
            DataTable dt = new DataTable();
            if (HttpContext.Request.Form.Files.Any())
            {
                foreach (var file in HttpContext.Request.Form.Files)
                {
                    var path = Path.Combine(environment.ContentRootPath, "Upload", file.FileName);
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    // dt=pdfInputfile.singlefile(path);
                    dt = await _unitOfWork.PdfExtraction.upload(path);
                    string JSONString = string.Empty;
                    JSONString = JsonConvert.SerializeObject(dt);
                    //return JSONString;
                }
            }

        }

        [HttpGet]
        public async Task<string> GetTask()
        {
            DataTable dt = new DataTable();
            string JSONString = string.Empty;
            if (HttpContext.Request.Form.Files.Any())
            {
                foreach (var file in HttpContext.Request.Form.Files)
                {
                    var path = Path.Combine(environment.ContentRootPath, "Upload", file.FileName);
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    dt = pdfInputfile.singlefile(path);


                    JSONString = JsonConvert.SerializeObject(dt);
                    return JSONString;
                }
            }

            return JSONString;
        }


        [HttpPost]
        [Route("upload1")]
        public async Task<string> GetLineStatuses()
        {
            string JSONString = string.Empty;
            DataTable dt = new DataTable();
            if (HttpContext.Request.Form.Files.Any())
            {
                foreach (var file in HttpContext.Request.Form.Files)
                {
                    var path = Path.Combine(environment.ContentRootPath, "Upload", file.FileName);
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                   // dt = pdfInputfile.singlefile(path);
                    dt = await _unitOfWork.PdfExtraction.upload(path);
                    JSONString = JsonConvert.SerializeObject(dt);
                    return JSONString;
                   
                }
            }
            return JSONString;
        }
    }
}
