﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ActivityMasterController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public ActivityMasterController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Json(_unitOfWork.ActivityMaster.GetAll(null, null, "SubThreadMaster,UserMaster").ToList());
        }



        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var objFromDb = _unitOfWork.ActivityMaster.GetFirstOrDefault(u => u.Id == id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting" });
            }
            _unitOfWork.ActivityMaster.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful" });
        }

        [HttpPost]
        [Route("Create")]
        public void Create([FromBody] ActivityMaster activity)
        {
            //if (ModelState.IsValid)
            {
                ActivityMaster activityMaster = _unitOfWork.ActivityMaster.GetFirstOrDefault(x => x.ActivityName == activity.ActivityName);
                if (activityMaster == null)
                {
                    _unitOfWork.ActivityMaster.Add(activity);
                    _unitOfWork.Save();
                }

                else
                {
                    activityMaster.ActivityName = activity.ActivityName;
                    activityMaster.SubThreadMaster = activity.SubThreadMaster;
                    activityMaster.ActivityLevel = activity.ActivityLevel;
                    activityMaster.ActivityOrder = activity.ActivityOrder;
                    activityMaster.ActivityPrecedence = activity.ActivityPrecedence;

                    _unitOfWork.ActivityMaster.Update(activityMaster);
                    _unitOfWork.Save();
                }

            }
        }

        [HttpGet]
        [Route("GetById")]
        public IActionResult GetById(Guid id)
        {
            return Json(_unitOfWork.ActivityMaster.GetFirstOrDefault(x => x.Id == id));
        }



    }
}
