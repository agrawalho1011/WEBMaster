﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ActivityController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public ActivityController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Json(_unitOfWork.ActivityMaster.GetAll(null, null, "SubThreadMaster,UserMaster").ToList());
        }

        [HttpGet]
        [Route("GetById")]
        public IActionResult GetById(Guid id)
        {
            return Json(_unitOfWork.ActivityMaster.GetFirstOrDefault(x => x.Id == id));
        }

        [HttpGet]
        [Route("GetAllActivityFile")]
        public IActionResult GetAllActivityFile(Guid id)
        {
            List<ActivityTracker> activityTrackers = _unitOfWork.ActivityTracker.GetAll(x => x.FileId == id).ToList();
            List<ActivityMaster> activityMasters = _unitOfWork.ActivityMaster.GetAll(x => x.ActivityLevel == "File").ToList();

            List<ActivityTracker> query = (from activity in activityMasters
                        join track in activityTrackers
                        on
                        activity.Id  equals track.ActivityId into gj
                        from subactivity in gj.DefaultIfEmpty()
                        select new ActivityTracker {   }).ToList();


            return Json(query);
        }
    }
}
