﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleMasterController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public RoleMasterController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult Get()
        {
            //return Json(new { data = _unitOfWork.SP_Call.ReturnList<Thread>("usp_GetAllThread", null) });
            return Json(_unitOfWork.RoleMaster.GetAll(null,null,"UserMaster").ToList());

        }


        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var objFromDb = _unitOfWork.RoleMaster.GetFirstOrDefault(u => u.Id == id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting" });
            }
            _unitOfWork.RoleMaster.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful" });
        }


        [HttpPost]
        [Route("Create")]
        public void Create([FromBody] RoleMaster roleMaster)
        {
            //if (ModelState.IsValid)
            {
                RoleMaster role = _unitOfWork.RoleMaster.GetFirstOrDefault(x => x.Id == roleMaster.Id);
                if (role == null)
                {
                    _unitOfWork.RoleMaster.Add(roleMaster);
                    _unitOfWork.Save();

                }
                else
                {
                    role.RoleName = roleMaster.RoleName;
                    role.CreatedBy = roleMaster.CreatedBy;
                    role.CreatedDate = roleMaster.CreatedDate;
                    role.IsActive = roleMaster.IsActive;
                   
                    _unitOfWork.RoleMaster.Update(role);
                    _unitOfWork.Save();
                }
            }
        }


        [HttpGet]
        [Route("GetById")]
        public IActionResult GetById(Guid id)
        {
            return Json(_unitOfWork.RoleMaster.GetFirstOrDefault(x => x.Id == id));
        }
    }
}