﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ActivityTrackerController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public ActivityTrackerController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult Get()
        {
            //return Json(new { data = _unitOfWork.SP_Call.ReturnList<ActivityTracker>("usp_GetAllActivityTracker", null) });
            return Json(new { data = _unitOfWork.ActivityTracker.GetAll().ToList() });
        }


        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var objFromDb = _unitOfWork.ActivityTracker.GetFirstOrDefault(u => u.Id == id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting" });
            }
            _unitOfWork.ActivityTracker.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful" });
        }

        [HttpGet]
        [Route("GetByFileId")]
        public IActionResult GetByFileId(Guid id)
        {
            return Json(_unitOfWork.ActivityTracker.GetAll(x => x.FileId == id,null,"ActivityMaster").ToList());
        }
    }
}
