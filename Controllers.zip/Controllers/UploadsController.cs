﻿using System;
using System.IO;
using Microsoft.AspNetCore.Mvc;
using SixLabors.ImageSharp.Formats;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using Tesseract;
using Microsoft.Extensions.Hosting;


namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UploadsController : ControllerBase
    {
        private readonly IHostEnvironment _env;

        public UploadsController(IHostEnvironment env)
        {
            _env = env;
        }

        [HttpPost]
        public string Post([FromBody] string filename)
        {
            try
            {
                string path = Path.Combine(_env.ContentRootPath, "wwwroot");

                string file = Base64ToImage(filename, path);
                string image_content = "";
                using (var tesseractEngine = new TesseractEngine(@"C:\Users\tusha\source\repos\gitprojectoffice\Web\Web\Client\wwwroot\tessdata", "eng", EngineMode.Default))
                {
                    using (var srcImg = Pix.LoadFromFile(file))
                    {
                        using (var page = tesseractEngine.Process(srcImg))
                        {
                            image_content = page.GetText();

                            return image_content;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return "";
            }
        }

        public string Base64ToImage(string base64, string path)
        {
            string filepath = "";
            try
            {
                string ImagePrefix = base64.Remove(0, base64.LastIndexOf(","));
                byte[] data = Convert.FromBase64String(ImagePrefix.TrimStart(','));
                using (Image image = Image.Load(data, out IImageFormat format))
                {
                    string newName = Guid.NewGuid().ToString("N").Substring(0, 12);
                    string formats = format.Name == "JPEG" ? ".jpg" : "." + format.Name.ToLower();
                    string filename = newName + formats;
                    filepath = path + "/images/" + filename;
                    if (image.Width > 1024)
                    {
                        image.Mutate(s => s.Resize(1024, ((1024 * image.Height) / image.Width)));
                        image.Save(filepath);
                    }
                    else
                    {
                        image.Save(filepath);
                    }
                }
                return filepath;
            }
            catch (Exception ex)
            {
                return "";
            }
        }

    }
}
