﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContainerTrackController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public ContainerTrackController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        [Route("GetTrackingDetail")]
        public async Task<IActionResult> GetTrackingDetail(string ContainerList)
        {
            List<Root> root = new List<Root>();
            
            foreach (string str in ContainerList.Split(",",StringSplitOptions.RemoveEmptyEntries))
            {
                string url = "https://api.maerskline.com/track/" + str + "";
                HttpClient client = new HttpClient();
                try
                {
                    Root res = await client.GetFromJsonAsync<Root>(url);
                    root.Add(res);
                }
                catch
                {
                    //root.Add(new Root { containers = new List<Container> { new Container { container_num = str } } });
                }
            }
            return Json(root);
        }
        [HttpGet]
        [Route("GetTrackingDetailById")]
        public async Task<IActionResult> GetTrackingDetailById(string Container)
        {
            Root root = new Root();

            //foreach (string str in ContainerList.Split(",", StringSplitOptions.RemoveEmptyEntries))
            {
                string url = "https://api.maerskline.com/track/" + Container + "";
                HttpClient client = new HttpClient();
                try
                {
                    Root res = await client.GetFromJsonAsync<Root>(url);
                    return Json(res);
                }
                catch
                {
                    return Json("{data = 'No Data' }");
                    //root.Add(new Root { containers = new List<Container> { new Container { container_num = str } } });
                }
            }
            
        }
    }
}
