﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ThreadMasterController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public ThreadMasterController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult Get()
        {
            //return Json(new { data = _unitOfWork.SP_Call.ReturnList<Thread>("usp_GetAllThread", null) });
            return Json(_unitOfWork.ThreadMaster.GetAll());
        }

        [HttpPost]
        [Route("Create")]
        public void Create([FromBody] ThreadMaster threadmaster)
        {
            //if (ModelState.IsValid)
            {
                ThreadMaster thread = _unitOfWork.ThreadMaster.GetFirstOrDefault(x => x.Id == threadmaster.Id);
                if (thread == null)
                {
                    _unitOfWork.ThreadMaster.Add(threadmaster);
                    _unitOfWork.Save();

                }
                else
                {
                    thread.ThreadName = threadmaster.ThreadName;
                    _unitOfWork.ThreadMaster.Update(thread);
                    _unitOfWork.Save();
                }
            }
        }
        [HttpGet]
        [Route("GetById")]
        public IActionResult GetById(Guid id)
        {
            return Json(_unitOfWork.ThreadMaster.GetFirstOrDefault(x => x.Id == id));
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var objFromDb = _unitOfWork.ThreadMaster.GetFirstOrDefault(u => u.Id == id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting" });
            }
            _unitOfWork.ThreadMaster.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful" });
        }

    }
}
