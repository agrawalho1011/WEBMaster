﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class RegionMasterController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public RegionMasterController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult Get()
        {
            //return Json(new { data = _unitOfWork.SP_Call.ReturnList<RegionMaster>("usp_GetAllRegionMaster", null) });
            return Json(_unitOfWork.RegionMaster.GetAll(null, null, "UserMaster").ToList());
        }


        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var objFromDb = _unitOfWork.RegionMaster.GetFirstOrDefault(u => u.Id == id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting" });
            }
            _unitOfWork.RegionMaster.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful" });
        }

        [HttpPost]
        [Route("Create")]
        public void Create([FromBody] RegionMaster regionmaster)
        {
            //if (ModelState.IsValid)
            {
                RegionMaster region = _unitOfWork.RegionMaster.GetFirstOrDefault(x => x.Id == regionmaster.Id);
                if (region == null)
                {
                    _unitOfWork.RegionMaster.Add(regionmaster);
                    _unitOfWork.Save();

                }
                else
                {
                    region.RegionName = regionmaster.RegionName;
                    region.CreatedBy = regionmaster.CreatedBy;
                    region.EnterDate = regionmaster.EnterDate;
                   
                    _unitOfWork.RegionMaster.Update(region);
                    _unitOfWork.Save();
                }
            }
        }


        [HttpGet]
        [Route("GetById")]
        public IActionResult GetById(Guid id)
        {
            return Json(_unitOfWork.RegionMaster.GetFirstOrDefault(x => x.Id == id));
        }

    }
}
