﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class LocationMasterController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public LocationMasterController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult Get()
        {
            //return Json(new { data = _unitOfWork.SP_Call.ReturnList<LocationMaster>("usp_GetAllLocationMaster", null) });
            return Json(_unitOfWork.LocationMaster.GetAll(null,null,"UserMaster,RegionMaster").ToList());
        }


        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var objFromDb = _unitOfWork.LocationMaster.GetFirstOrDefault(u => u.Id == id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting" });
            }
            _unitOfWork.LocationMaster.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful" });
        }

        [HttpPost]
        [Route("Create")]
        public void Create([FromBody] LocationMaster locationmaster)
        {
            //if (ModelState.IsValid)
            {
                LocationMaster location = _unitOfWork.LocationMaster.GetFirstOrDefault(x => x.Id == locationmaster.Id);
                if (location == null)
                {
                    _unitOfWork.LocationMaster.Add(locationmaster);
                    _unitOfWork.Save();

                }
                else
                {
                    location.LocationName = locationmaster.LocationName;
                    location.RegionID = locationmaster.RegionID;
                    location.CreatedBy = locationmaster.CreatedBy;
                    location.CreatedDate = locationmaster.CreatedDate;

                    _unitOfWork.LocationMaster.Update(location);
                    _unitOfWork.Save();
                }
            }
        }


        [HttpGet]
        [Route("GetById")]
        public IActionResult GetById(Guid id)
        {
            return Json(_unitOfWork.LocationMaster.GetFirstOrDefault(x => x.Id == id));
        }
    }
}
