﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class HBLMasterController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public HBLMasterController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult Get()
        {
            //return Json(new { data = _unitOfWork.SP_Call.ReturnList<HBLMaster>("usp_GetAllHBLMaster", null) });
            return Json(_unitOfWork.HBLMaster.GetAll(null, null, "FileMaster,LocationMaster").ToList());
        }


        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var objFromDb = _unitOfWork.HBLMaster.GetFirstOrDefault(u => u.Id == id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting" });
            }
            _unitOfWork.HBLMaster.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful" });
        }


        [HttpPost]
        [Route("Create")]
        public void Create([FromBody] HBLMaster hblmaster)
        {
            //if (ModelState.IsValid)
            {
                HBLMaster hbl = _unitOfWork.HBLMaster.GetFirstOrDefault(x => x.Id == hblmaster.Id);
                if (hbl == null)
                {
                    _unitOfWork.HBLMaster.Add(hblmaster);
                    _unitOfWork.Save();

                }
                else
                {
                    hbl.HBLNo = hblmaster.HBLNo;
                    hbl.FileId = hblmaster.FileId;
                    hbl.LocationId = hblmaster.LocationId;
                    hbl.BookingNo = hblmaster.BookingNo;
                    hbl.HBLCustomerName = hblmaster.HBLCustomerName;
                    hbl.HBLFrontDesk = hblmaster.HBLFrontDesk;
                    hbl.CreatedBy = hblmaster.CreatedBy;
                    hbl.CreatedDate = hblmaster.CreatedDate;
                    hbl.IsActive = hblmaster.IsActive;
                    _unitOfWork.HBLMaster.Update(hbl);
                    _unitOfWork.Save();
                }
            }
        }


        [HttpPost]
        [Route("Bulk")]
        public void Bulk([FromBody] List<HBLMaster> hblmaster_list)
        {
            //if (ModelState.IsValid)
            foreach (HBLMaster hblmaster in hblmaster_list)
            {
                HBLMaster hbl = _unitOfWork.HBLMaster.GetFirstOrDefault(x => x.Id == hblmaster.Id);
                if (hbl == null)
                {
                    _unitOfWork.HBLMaster.Add(hblmaster);
                }
                else
                {
                    hbl.HBLNo = hblmaster.HBLNo;
                    hbl.FileId = hblmaster.FileId;
                    hbl.LocationId = hblmaster.LocationId;
                    hbl.BookingNo = hblmaster.BookingNo;
                    hbl.HBLCustomerName = hblmaster.HBLCustomerName;
                    hbl.HBLFrontDesk = hblmaster.HBLFrontDesk;
                    hbl.CreatedBy = hblmaster.CreatedBy;
                    hbl.CreatedDate = hblmaster.CreatedDate;
                    hbl.IsActive = hblmaster.IsActive;
                    _unitOfWork.HBLMaster.Update(hbl);
                }
            }
            _unitOfWork.Save();
        }


        [HttpGet]
        [Route("GetById")]
        public IActionResult GetById(Guid id)
        {
            return Json(_unitOfWork.HBLMaster.GetFirstOrDefault(x => x.Id == id));
        }
    }
}
