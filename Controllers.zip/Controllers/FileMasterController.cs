﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class FileMasterController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public FileMasterController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult Get()
        {
            //return Json(new { data = _unitOfWork.SP_Call.ReturnList<FileMaster>("usp_GetAllFileMaster", null) });
            return Json(_unitOfWork.FileMaster.GetAll(null, null, "UserMaster").ToList());
        }


        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var objFromDb = _unitOfWork.FileMaster.GetFirstOrDefault(u => u.Id == id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting" });
            }
            _unitOfWork.FileMaster.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful" });
        }

        [HttpPost]
        [Route("Create")]
        public void Create([FromBody] FileMaster filemaster)
        {
            //if (ModelState.IsValid)
            {
                FileMaster file = _unitOfWork.FileMaster.GetFirstOrDefault(x => x.Id == filemaster.Id);
                if (file == null)
                {
                    _unitOfWork.FileMaster.Add(filemaster);
                    _unitOfWork.Save();

                }
                else
                {
                    file.FileNo = filemaster.FileNo;
                    file.CreatedBy = filemaster.CreatedBy;
                    file.CreatedDate = filemaster.CreatedDate;
                    _unitOfWork.FileMaster.Update(file);
                    _unitOfWork.Save();
                }
            }
        }


        [HttpPost]
        [Route("Bulk")]
        public void Bulk([FromBody] List<FileMaster> filemaster_list)
        {
            //if (ModelState.IsValid)
            {
                foreach (FileMaster filemaster in filemaster_list)
                {
                    FileMaster file = _unitOfWork.FileMaster.GetFirstOrDefault(x => x.Id == filemaster.Id);

                    if (file == null)
                    {
                        _unitOfWork.FileMaster.Add(filemaster);
                    }
                    else
                    {
                        file.FileNo = filemaster.FileNo;
                        file.CreatedBy = filemaster.CreatedBy;
                        file.CreatedDate = filemaster.CreatedDate;
                        _unitOfWork.FileMaster.Update(file);

                    }
                }
                _unitOfWork.Save();
            }
        }


        [HttpGet]
        [Route("GetById")]
        public IActionResult GetById(Guid id)
        {
            return Json(_unitOfWork.FileMaster.GetFirstOrDefault(x => x.Id == id));
        }
    }
}
