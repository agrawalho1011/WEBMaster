﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.DataAccess.Data.Repository;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Web.DataAccess.Data.Repository
{
    public class ActivityTrackerRepository : Repository<ActivityTracker>, IActivityTrackerRespository
    {
        private readonly ApplicationDbContext _db;

        public ActivityTrackerRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetActivityTrackerListForDropDown()
        {
            return _db.ActivityTracker.Select(i => new SelectListItem()
            {
                Text = i.UserMaster.FullName,
                Value = i.Id.ToString()
            });

        }
    }
}
