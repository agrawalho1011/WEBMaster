﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using Web.DataAccess.Data.Repository;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;
using System.Linq;

namespace Web.DataAccess.Data.Repository
{
    public class RegionMasterRepository : Repository<RegionMaster>, IRegionMasterRespository
    {
        private readonly ApplicationDbContext _db;

        public RegionMasterRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetRegionMasterListForDropDown()
        {
            return _db.RegionMaster.Select(i => new SelectListItem()
            {
                Text = i.RegionName,
                Value = i.Id.ToString()
            });

        }
    }
}
