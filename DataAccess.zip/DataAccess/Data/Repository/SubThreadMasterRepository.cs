﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using Web.DataAccess.Data.Repository;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;
using System.Linq;

namespace Web.DataAccess.Data.Repository
{
    public class SubThreadMasterRepository : Repository<SubThreadMaster>, ISubThreadMasterRespository
    {
        private readonly ApplicationDbContext _db;

        public SubThreadMasterRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetSubThreadMasterListForDropDown()
        {
            return _db.SubThreadMaster.Select(i => new SelectListItem()
            {
                Text = i.SubThread,
                Value = i.Id.ToString()
            });

        }
    }
}
