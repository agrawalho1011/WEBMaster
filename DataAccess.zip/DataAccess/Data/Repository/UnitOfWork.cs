﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;

namespace Web.DataAccess.Data.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _db;

        public UnitOfWork(ApplicationDbContext db)
        {
            _db = db;
            SP_Call = new SP_Call(_db);
            ActivityMaster = new ActivityMasterRepository(_db);
            ActivityTracker = new ActivityTrackerRepository(_db);
            FileMaster = new FileMasterRepository(_db);
            HBLMaster = new HBLMasterRepository(_db);
            LocationMaster = new LocationMasterRepository(_db);
            RegionMaster = new RegionMasterRepository(_db);
            RoleMaster = new RoleMasterRepository(_db);
            SubThreadMaster = new SubThreadMasterRepository(_db);
            ThreadMaster = new ThreadMasterRepository(_db);
            UserMaster = new UserMasterRepository(_db);
            PdfExtraction = new PdfExtractionRespository(_db);
        }
      
        public ISP_Call SP_Call { get; private set; }
        public IActivityMasterRespository ActivityMaster { get; private set; }
        public IActivityTrackerRespository ActivityTracker { get; private set; }
        public IFileMasterRespository FileMaster { get; private set; }
        public IHBLMasterRespository HBLMaster { get; private set; }
        public ILocationMasterRespository LocationMaster { get; private set; }
        public IRegionMasterRespository RegionMaster { get; private set; }
        public IRoleMasterRespository RoleMaster { get; private set; }
        public ISubThreadMasterRespository SubThreadMaster { get; private set; }
        public IThreadMasterRespository ThreadMaster { get; private set; }
        public IUserMasterRespository UserMaster { get; private set; }
        public IPdfExtractionRespository PdfExtraction { get; set; }

        public void Dispose()
        {
            _db.Dispose();
        }

        public void Save()
        {
            _db.SaveChanges();
        }
    }
}