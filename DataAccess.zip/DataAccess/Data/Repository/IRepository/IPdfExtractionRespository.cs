﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using Web.Model.Model;

namespace Web.DataAccess.Data.Repository.IRepository
{
    
   
    public interface IPdfExtractionRespository:IRepository<PortList>
    {
        
        public Task<DataTable> upload(string fpath);

      
    }
}