﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.DataAccess.Data.Repository.IRepository
{
    public interface IUnitOfWork : IDisposable
    {
        IActivityMasterRespository ActivityMaster { get; }
        IActivityTrackerRespository ActivityTracker { get; }
        IFileMasterRespository FileMaster { get; }
        IHBLMasterRespository HBLMaster { get; }
        ILocationMasterRespository LocationMaster { get; }
        IRegionMasterRespository RegionMaster { get; }
        IRoleMasterRespository RoleMaster { get; }
        ISubThreadMasterRespository SubThreadMaster { get; }
        IThreadMasterRespository ThreadMaster { get; }
        IUserMasterRespository UserMaster { get; }
        IPdfExtractionRespository PdfExtraction { get; set; }
        ISP_Call SP_Call { get; }
        void Save();
    }
}
