﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using Web.Model.Model;

namespace Web.DataAccess.Data.Repository.IRepository
{
    public interface IActivityTrackerRespository : IRepository<ActivityTracker>
    {
        IEnumerable<SelectListItem> GetActivityTrackerListForDropDown();
    }
}
