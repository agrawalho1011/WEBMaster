﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Model.Model;

namespace Web.DataAccess.Data.Repository.IRepository
{
    public interface IHBLMasterRespository : IRepository<HBLMaster>
    {
        IEnumerable<SelectListItem> GetHBLMasterListForDropDown();
    }
}
