﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using Web.DataAccess.Data.Repository;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;
using System.Linq;

namespace Web.DataAccess.Data.Repository
{
    public class ActivityMasterRepository : Repository<ActivityMaster>, IActivityMasterRespository
    {
        private readonly ApplicationDbContext _db;

        public ActivityMasterRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetActivityMasterListForDropDown()
        {
            return _db.ActivityMaster.Select(i => new SelectListItem()
            {
                Text = i.ActivityName,
                Value = i.Id.ToString()
            });

        }
    }
}
