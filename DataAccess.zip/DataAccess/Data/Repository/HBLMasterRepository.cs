﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using Web.DataAccess.Data.Repository;
using Web.DataAccess.Data.Repository.IRepository;
using Web.Model.Model;
using System.Linq;

namespace Web.DataAccess.Data.Repository
{
    public class HBLMasterRepository : Repository<HBLMaster>, IHBLMasterRespository
    {
        private readonly ApplicationDbContext _db;

        public HBLMasterRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetHBLMasterListForDropDown()
        {
            return _db.HBLMaster.Select(i => new SelectListItem()
            {
                Text = i.HBLNo,
                Value = i.Id.ToString()
            });

        }
    }
}
