﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using Web.Model;
using Web.Model.Model;

namespace Web.DataAccess
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<ActivityMaster> ActivityMaster { get; set; }
        public DbSet<ActivityTracker> ActivityTracker { get; set; }
        public DbSet<FileMaster> FileMaster { get; set; }
        public DbSet<HBLMaster> HBLMaster { get; set; }
        public DbSet<LocationMaster> LocationMaster { get; set; }
        public DbSet<RegionMaster> RegionMaster { get; set; }
        public DbSet<RoleMaster> RoleMaster { get; set; }
        public DbSet<SubThreadMaster> SubThreadMaster { get; set; }
        public DbSet<ThreadMaster> ThreadMaster { get; set; }
        public DbSet<UserMaster> UserMaster { get; set; }
       
        public DbSet<PortList> PortList { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            
        }
    }
}
