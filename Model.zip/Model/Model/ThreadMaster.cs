﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Web.Model.Model
{
    public class ThreadMaster
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Display (Name ="Thread Name")]
        public string ThreadName { get; set; } 

    }
}
