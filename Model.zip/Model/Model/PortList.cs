﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Web.Model.Model
{
    public class PortList
    {
        [Key]
        public int id { get; set; }
        public string Port { get; set; }
        public string IATA { get; set; }
        public string UnCode { get; set; }
        public string Country { get; set; }
        public string Region { get; set; }
    }
}
