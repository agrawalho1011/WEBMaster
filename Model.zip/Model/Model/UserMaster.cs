﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Web.Model.Model
{
	public class UserMaster
	{
		[Key]
		public Guid Id { get; set; } = Guid.NewGuid();

		[Required]
		[Display(Name = "User ID")]
		public int WNSUserID { get; set; }

		[Required]
		[Display(Name = "User Name")]
		public string FirstName { get; set; }

		[Required]
		public string LastName { get; set; }

		[NotMapped]
		public string FullName { get { return FirstName + " " + LastName; } }

		[Required]
		[Display(Name = "Joining Date")]
		[DisplayFormat(DataFormatString = "{MMM-dd-yyyy}")]
		public DateTime JoiningDate { get; set; }
		
		//[Display(Name = "Role ID")]
		//public Guid RoleID { get; set; }
		//[ForeignKey("RoleId")]
		//public virtual RoleMaster RoleMaster { get; set; }

		public bool IsActive { get; set; } = true;

		[Display(Name = "Created By")]
		public Guid CreatedBy { get; set; }

		public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
		
	}
}
