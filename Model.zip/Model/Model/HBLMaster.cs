﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Web.Model.Model
{
    public class HBLMaster
    {
		[Key]
		public Guid Id { get; set; } = Guid.NewGuid();

		[Required]
		[Display (Name ="HBL Number")]
		public string HBLNo { get; set; }

		[Display(Name = "File Number")]
		public Guid? FileId { get; set; }
		[ForeignKey ("FileId")]
		public virtual FileMaster FileMaster { get; set; }

		[Display(Name = "Location")]
		public Guid? LocationId { get; set; }
		[ForeignKey("LocationId")]
		public virtual LocationMaster LocationMaster { get; set; }

		[Display(Name = "Booking Number")]
		public string BookingNo { get; set; }
		
		public string HBLCustomerName { get; set; }
		
		public string HBLFrontDesk { get; set; }
		
		public string CreatedBy { get; set; }
		
		public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
		
		public bool IsActive { get; set; } = true;
	}
}
