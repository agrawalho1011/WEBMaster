﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Web.Model.Model
{
    public class RegionMaster
    {
		[Key]
		public Guid Id { get; set; } = Guid.NewGuid();

		[Required]
		[Display (Name ="Region Name")]
		public string RegionName { get; set; }

		[Display (Name ="Created By")]
		public Guid? CreatedBy { get; set; }
		[ForeignKey("CreatedBy")]
		public virtual UserMaster UserMaster { get; set; }

		public DateTime EnterDate { get; set; } = DateTime.UtcNow;
		
	}
}
