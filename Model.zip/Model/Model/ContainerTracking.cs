﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Model.Model
{
    public class Origin
    {
        public string terminal { get; set; }
        public string geo_site { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string country_code { get; set; }
        public string geoid_city { get; set; }
        public string site_type { get; set; }
    }
    public class Destination
    {
        public string terminal { get; set; }
        public string geo_site { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string country_code { get; set; }
        public string geoid_city { get; set; }
        public string site_type { get; set; }
    }
    public class Event
    {
        public string activity { get; set; }
        public bool stempty { get; set; }
        public string actfor { get; set; }
        public string vessel_name { get; set; }
        public string voyage_num { get; set; }
        public string vessel_num { get; set; }
        public DateTime actual_time { get; set; }
        public string rkem_move { get; set; }
        public bool is_cancelled { get; set; }
        public bool is_current { get; set; }
        public DateTime? expected_time { get; set; }
    }
    public class Location
    {
        public string terminal { get; set; }
        public string geo_site { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string country_code { get; set; }
        public string geoid_city { get; set; }
        public string site_type { get; set; }
        public List<Event> events { get; set; }
    }
    public class Latest
    {
        public DateTime actual_time { get; set; }
        public string activity { get; set; }
        public bool stempty { get; set; }
        public string actfor { get; set; }
        public string geo_site { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string country_code { get; set; }
    }

    public class Container
    {
        public string container_num { get; set; }
        public string container_size { get; set; }
        public string container_type { get; set; }
        public string iso_code { get; set; }
        public string @operator { get; set; }
        public List<Location> locations { get; set; }
        public DateTime eta_final_delivery { get; set; }
        public Latest latest { get; set; }
        public string status { get; set; }
    }
    public class Root
    {
        public bool isContainerSearch { get; set; }
        public Origin origin { get; set; }
        public Destination destination { get; set; }
        public List<Container> containers { get; set; }
    }
}
