﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Web.Model.Model
{
    public class ActivityMaster
    {
		[Key]
		public Guid Id { get; set; } = Guid.NewGuid();

		[Required]
		[Display (Name ="Activity Name")]
		public string ActivityName { get; set; }
		
		[Display (Name ="Sub Thread ID")]
		public Guid? SubThreadID { get; set; }
		[ForeignKey("SubThreadID")]
		public virtual SubThreadMaster SubThreadMaster { get; set; }

		[Required]
		[Display(Name = "Level")]
		public string ActivityLevel { get; set; }

		[Required]
		[Display(Name = "Order")]
		public int ActivityOrder { get; set; }

		[Required]
		[Display(Name = "Precedence")]
		public int ActivityPrecedence { get; set; }

		[Display(Name = "Created By")]
		public Guid? CreatedBy { get; set; }
		[ForeignKey("CreatedBy")]
		public virtual UserMaster UserMaster { get; set; }

		public DateTime CreatedDate { get; set; }

	}
}
