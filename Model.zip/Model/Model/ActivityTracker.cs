﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Web.Model.Model
{
    public class ActivityTracker
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();
        [Display(Name = "Activity Name")]
        public Guid? ActivityId { get; set; }
        [ForeignKey("ActivityId")]
        public virtual ActivityMaster ActivityMaster { get; set; }

        [Display(Name = "File No")]
        public Guid? FileId { get; set; }
        [ForeignKey("FileId")]
        public virtual FileMaster FileMaster { get; set; }

        [Display(Name = "HBL No")]
        public Guid? HBLId { get; set; }
        [ForeignKey("HBLId")]
        public virtual HBLMaster HBLMaster { get; set; }

        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        [Display(Name = "Activity Done By")]
        public Guid? ActivityUser { get; set; }
        [ForeignKey("ActivityUser")]
        public virtual UserMaster UserMaster { get; set; }
        [NotMapped]
        [Display(Name = "Average Handling Time")]
        public TimeSpan AHT { get { return EndTime - StartTime; } }

        public Status ActivityStatus { get; set; }

        public string Comment { get; set; }
    }
}

