﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Web.Model.Model
{
    public class LocationMaster
    {
		[Key]
		public Guid Id { get; set; } = Guid.NewGuid();

		[Required]
		[Display(Name = "Location")]
		public string LocationName { get; set; }


		[Display(Name = "Region")]
		public Guid? RegionID { get; set; }
		[ForeignKey("RegionID")]
		public virtual RegionMaster RegionMaster { get; set; }

		[Display (Name ="Created By")]
		public Guid? CreatedBy { get; set; }
		[ForeignKey("CreatedBy")]
		public virtual UserMaster UserMaster { get; set; }

		public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
		
	}
}
