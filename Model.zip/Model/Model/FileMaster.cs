﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Web.Model.Model
{
    public class FileMaster
    {
		[Key]
		public Guid Id { get; set; } = Guid.NewGuid();
		
		[Display(Name = "Received Date and Time")]
		public DateTime ReceivedDateTime { get; set; } 

		[Required]
		[Display(Name = "File Number")]
		public string FileNo { get; set; }

		[Display(Name = "File Destination")]
		public string FileDestination { get; set; }


		[Display(Name = "Draft CutOff Date and Time")]
		public DateTime DraftCutOffDateTime { get; set; }

		[Display(Name = "MBL CutOff Date and Time")]
		public DateTime MBLCutOffDateTime { get; set; }

		[Display(Name = "Created By")]
		public Guid? CreatedBy { get; set; }
		[ForeignKey("CreatedBy")]
		public virtual UserMaster UserMaster { get; set; }

		public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
	}
}
