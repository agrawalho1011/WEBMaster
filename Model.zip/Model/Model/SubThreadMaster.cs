﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Web.Model.Model
{
    public class SubThreadMaster
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();
          
        [Display(Name = "Sub Thread Name")]
        public string SubThread { get; set; }

        [Display(Name = "Thread Name")]
        public Guid? ThreadID { get; set; } 
        [ForeignKey("ThreadID")]
        public virtual ThreadMaster ThreadMaster { get; set; }


    }
}
