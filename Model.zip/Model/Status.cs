﻿
public enum Status
{
    Completed,
    Pending,
    InProcess,
    Query,
    QueryResolved
}
