﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Web.BLValidation
{
    public class texttemplate
    {
        public void createfile(string path)
        {
            if (!File.Exists(path))
            {
                //File.Create(path);
                string[] lines = {"head,x1,y1,x2,y2,T,LAdd",
                                    "B L No.,500,790,600,800,L,0",

                                    //"B L No.,650,810,570,788,L,0",
                                    "Reference No.,400,750,600,790,L,0",
                                    "Shipper,23,740,200,796,L,1",
                                    "ShipperAddress,23,735,200,800,L,-1",
                                    "Consignee,23,726,200,650,L,1",
                                    "ConsigneeAddress,23,726,200,650,L,-1",
                                    "Notify,23,640,200,580,L,1",
                                    "NotifyAddress,23,640,200,580,L,-1",
                                    "Pre carriage by,24,570,180,Vessel,SY2,-15",
                                    "Vessel,24,540,190,Port of Discharge,SY2,-12",
                                    "PLR,192,570,220,Port of loading,SY2,-15",
                                    "POL,192,540,280,Place of delivery,SY2,-12",
                                    "POD,24,522,190,Marks and Nos,SY2,-12",
                                    "PLD,192,522,250,Number and kind of packages,SY2,-12",
                                    "Marks Nos,23,485,120,FREIGHT PREPAID|FREIGHT COLLECT|EXPRESS B/L,SY2,-12",
                                    "Description,150,485,400,FREIGHT PREPAID|FREIGHT COLLECT|EXPRESS B/L,SY2,-12",
                                    "HS CODE,150,485,400,FREIGHT PREPAID|FREIGHT COLLECT|EXPRESS B/L,SY2,-12",
                                    "Weight,410,485,475,465,L,0",
                                    "Measurement,480,485,600,465,L,0",
                                    "Freight Type,,,,FREIGHT PREPAID|FREIGHT COLLECT,R,Not Found",
                                    "Freight payable at,275,75,290,Number of original Bs/L,SY2,-20",
                                    "Number of original Bs/L,220,15,370,5,L,0",
                                    "BL Type,,,,EXPRESS B/L|EXPRESS BL|SEAWAY BILL|SEAWAYBILL|EXPRESS BILL OF LADING|WAYBILL,C,EXPRESS B/L|Original",
                                    "FileNo,400,750,600,790, 1,1",
                                    "FreightBill,23,200,400, 750, 1,1",
                                };

                File.WriteAllLines(path, lines);
            }
        }
        public System.Data.DataTable readfile(string path)
        {
            System.Data.DataTable dt = new System.Data.DataTable("tbl_extract");
            if (!File.Exists(path))
            {
                createfile(path);
            }
            else
            {
                System.IO.File.Delete(path);
                createfile(path);
            }
            {

                string[] columns = null;
                var lines = File.ReadAllLines(path);
                if (lines.Count() > 0)
                {
                    columns = lines[0].Split(new char[] { ',' });

                    foreach (var column in columns)
                        dt.Columns.Add(column);
                }
                for (int i = 1; i < lines.Count(); i++)
                {
                    System.Data.DataRow dr = dt.NewRow();
                    string[] values = lines[i].Split(new char[] { ',' });
                    for (int j = 0; j < values.Count() && j < columns.Count(); j++)
                        dr[j] = values[j];
                    dt.Rows.Add(dr);
                }
            }
            return dt;
        }
    }
}
