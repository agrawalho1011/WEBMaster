﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using iTextSharp.text;
using iTextSharp.text.pdf;



namespace Web.BLValidation
{
    public class PdfInputfile 
    {
        pdfextractor p = new pdfextractor();
        texttemplate t = new texttemplate();
        DataTable dt = new DataTable();
        DataTable dt_structure;
        string pdffilepath="";
        public DataTable singlefile(string filepath)
        {

           
                 restructure();
            try
            {
                {
                    {
                        pdffilepath = filepath;
                        DataRow dr_new = dt.NewRow();
                        DataTable searchdt = p.searchpdf(pdffilepath);
                        foreach (DataRow dr in dt_structure.Rows)
                        {
                            if (dr_new[dr["head"].ToString()].ToString() == "")
                            {
                                string temp = "";
                                int x1 = 0;
                                int y1 = 0;
                                int x2 = 0;
                                int y2 = 0;
                                if (dr["T"].ToString() == "L" && dr["LAdd"].ToString() == "0")
                                {
                                    x1 = Convert.ToInt32(dr["x1"].ToString());
                                    y1 = Convert.ToInt32(dr["y1"].ToString());
                                    x2 = Convert.ToInt32(dr["x2"].ToString());
                                    y2 = Convert.ToInt32(dr["y2"].ToString());
                                }
                                if (dr["T"].ToString() == "L" && dr["LAdd"].ToString() != "0")
                                {
                                    x1 = Convert.ToInt32(dr["x1"].ToString());
                                    y1 = Convert.ToInt32(dr["y1"].ToString());
                                    x2 = Convert.ToInt32(dr["x2"].ToString());
                                    y2 = Convert.ToInt32(dr["y2"].ToString());

                                    string text = p.readpdf(pdffilepath, x1, y1, x2, y2).Trim().Replace("Shipper", "").Trim();
                                    string[] lines = text.Split(new[] { Environment.NewLine, "\n" }, StringSplitOptions.None);
                                    temp = "";
                                    if (Convert.ToInt32(dr["LAdd"].ToString()) > 0)
                                    {
                                        for (int i = 0; i < Convert.ToInt32(dr["LAdd"].ToString() != "0"); i++)
                                        {
                                            temp = temp + lines[i] + " ";
                                        }
                                    }
                                    else
                                    {
                                        for (int i = Math.Abs(Convert.ToInt32(dr["LAdd"].ToString())); i < lines.Length; i++)
                                        {
                                            temp = temp + lines[i] + " ";
                                        }
                                    }
                                    temp = temp.Trim();
                                }
                                else if (dr["T"].ToString() == "SX1")
                                {
                                    int index = p.searchdt(searchdt, dr["x1"].ToString().Split('|'));
                                    x1 = (int)Convert.ToDouble(searchdt.Rows[index]["XCor"].ToString()) - (int)Convert.ToDouble(dr["LAdd"].ToString()); ;
                                    y1 = Convert.ToInt32(dr["y1"].ToString());
                                    x2 = Convert.ToInt32(dr["x2"].ToString());
                                    y2 = Convert.ToInt32(dr["y2"].ToString());
                                }
                                else if (dr["T"].ToString() == "SY1")
                                {
                                    x1 = Convert.ToInt32(dr["x1"].ToString());
                                    int index = p.searchdt(searchdt, dr["y1"].ToString().Split('|'));
                                    y1 = (int)Convert.ToDouble(searchdt.Rows[index]["YCor"].ToString()) - (int)Convert.ToDouble(dr["LAdd"].ToString()); ;
                                    y2 = Convert.ToInt32(dr["y2"].ToString());
                                    x2 = Convert.ToInt32(dr["x2"].ToString());
                                }
                                else if (dr["T"].ToString() == "SX2")
                                {
                                    x1 = Convert.ToInt32(dr["x1"].ToString());
                                    y1 = Convert.ToInt32(dr["y1"].ToString());
                                    int index = p.searchdt(searchdt, dr["x2"].ToString().Split('|'));
                                    x2 = (int)Convert.ToDouble(searchdt.Rows[index]["XCor"].ToString()) - (int)Convert.ToDouble(dr["LAdd"].ToString()); ;
                                    y2 = Convert.ToInt32(dr["y2"].ToString());
                                }
                                else if (dr["T"].ToString() == "SY2")
                                {
                                    if (dr["head"].ToString() == "POL")
                                    {
                                        int k = 0;
                                    }

                                    x1 = Convert.ToInt32(dr["x1"].ToString());
                                    y1 = Convert.ToInt32(dr["y1"].ToString());
                                    x2 = Convert.ToInt32(dr["x2"].ToString());
                                    int index = p.searchdt(searchdt, dr["y2"].ToString().Split('|'));

                                    if (index != -1)
                                    {
                                        if ((dr["head"].ToString() == "Marks Nos" || dr["head"].ToString() == "Description" || dr["head"].ToString() == "HS CODE") && (Convert.ToInt32(searchdt.Rows[index]["PageNo"].ToString()) > 1))
                                        {
                                            int i = p.searchdt(searchdt, "Freight details, charges etc.");
                                            y2 = y1 - 180;

                                            temp = temp + p.readpdf(pdffilepath, x1, y1, x2, y2).Replace("Marks and Nos.", "").Replace("Particulars furnished by the Merchant", "").Trim();
                                            //drawRect(pdffilepath, x1, y1, x2, y2, 1);

                                            string xyz = p.readpdf(pdffilepath, 0, 100, 900, 600, 2);


                                            ///Code to capture Measurement and Weight in case of Attachement
                                            ///
                                            if (dr["head"].ToString() == "Description" && (dr_new["Measurement"].ToString() == "" || dr_new["Weight"].ToString() == ""))
                                            {
                                                //drawRect(pdffilepath, x1, y1, x2, y2, 1);
                                                if (temp.Contains("AS PER ATTACHED SHEET."))
                                                {
                                                    string volume = "";
                                                    try
                                                    {
                                                        volume = temp.Substring(temp.Substring(0, temp.LastIndexOf(" ")).LastIndexOf(" ") + 1);

                                                        if (!volume.Contains("CBM"))
                                                        {
                                                            //temp = temp.Substring(0,temp.LastIndexOf("CBM")).Trim();
                                                            volume = temp.Substring(temp.LastIndexOf("KG") + 2, (temp.LastIndexOf("CBM") - temp.LastIndexOf("KG")) + 1);
                                                            //volume = temp.Substring(temp.LastIndexOf(" "), temp.Length - temp.LastIndexOf(" "));
                                                        }

                                                        if (volume.Trim().ToUpper().Contains("CBM"))
                                                            volume = temp.Substring(temp.LastIndexOf("KG") + 2, (temp.LastIndexOf("CBM") - temp.LastIndexOf("KG")) + 1);
                                                        else
                                                            volume = "";

                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        volume = "";
                                                    }
                                                    //if (volume.ToUpper().Contains("CBM"))
                                                    //{
                                                    //    dr_new["Measurement"] = volume.ToUpper().Replace("CBM", "").Trim();
                                                    //}

                                                    dr_new["Measurement"] = volume.ToUpper().Trim();

                                                    string weight = temp.Substring(temp.LastIndexOf("SHEET.") + 6, (temp.ToUpper().LastIndexOf("KG") - temp.LastIndexOf("SHEET.") - 6)).Trim();

                                                    dr_new["Weight"] = weight;
                                                }
                                            }

                                            int NewPageTextIndex = p.searchdt(searchdt, "MarksNo");

                                            if (NewPageTextIndex != -1)
                                            {
                                                //int newX1 = Convert.ToInt32(searchdt.Rows[NewPageTextIndex]["XCor"].ToString());
                                                int newX1 = Convert.ToInt32(dr["x1"].ToString());


                                                int newY1 = Convert.ToInt32(searchdt.Rows[NewPageTextIndex]["YCor"].ToString().Substring(0, searchdt.Rows[NewPageTextIndex]["YCor"].ToString().IndexOf(".")));
                                                //else
                                                //    newY1 = (int)Convert.ToDouble(searchdt.Rows[index]["YCor"].ToString());

                                                int newX2 = Convert.ToInt32(dr["x2"].ToString());

                                                int index1 = p.searchdt(searchdt, dr["y2"].ToString().Split('|'));

                                                bool Freightflag = false;
                                                if (index1 != -1)
                                                {
                                                    y2 = (int)Convert.ToDouble(searchdt.Rows[index]["YCor"].ToString()) - (int)Convert.ToDouble(dr["LAdd"].ToString());

                                                    if (y2 > newY1)
                                                    {
                                                        y2 = 40;
                                                        Freightflag = true;
                                                    }
                                                }

                                                if (Freightflag == true)
                                                {
                                                    temp = temp + "\n" + p.readpdf(pdffilepath, newX1, newY1, newX2, y2, 2);
                                                }
                                                else
                                                {
                                                    temp = temp + "\n" + p.readpdf(pdffilepath, newX1, newY1, newX2, y2, Convert.ToInt32(searchdt.Rows[index1]["PageNo"].ToString()));
                                                }

                                                if (dr["head"].ToString() == "Description")
                                                {
                                                    temp = temp + xyz;
                                                }

                                            }
                                            //else
                                            //{
                                            //    temp = temp + "\n" + p.readpdf(pdffilepath, x1, y1, x2, y2,1);
                                            //}


                                            #region code for multiple page description

                                            //int NewPageTextIndex = p.searchdt(searchdt, "MarksNo");

                                            //int indexOfFreightTerm = p.searchdt(searchdt, dr["y2"].ToString().Split('|'));

                                            //int FreightTermPage = -1;
                                            //if (indexOfFreightTerm != -1)
                                            //    FreightTermPage = Convert.ToInt32(searchdt.Rows[indexOfFreightTerm]["PageNo"].ToString());

                                            //int MarksNoPage = 1;
                                            //if (NewPageTextIndex != -1)
                                            //    MarksNoPage = Convert.ToInt32(searchdt.Rows[NewPageTextIndex]["PageNo"].ToString());

                                            //if (NewPageTextIndex != -1 && MarksNoPage == FreightTermPage)
                                            //{
                                            //    int newX1 = Convert.ToInt32(dr["x1"].ToString());

                                            //    int newY1 = Convert.ToInt32(searchdt.Rows[NewPageTextIndex]["YCor"].ToString().Substring(0, searchdt.Rows[NewPageTextIndex]["YCor"].ToString().IndexOf(".")));

                                            //    int newX2 = Convert.ToInt32(dr["x2"].ToString());

                                            //    int index1 = p.searchdt(searchdt, dr["y2"].ToString().Split('|'));

                                            //    bool Freightflag = false;
                                            //    if (index1 != -1)
                                            //    {
                                            //        y2 = (int)Convert.ToDouble(searchdt.Rows[index]["YCor"].ToString()) - (int)Convert.ToDouble(dr["LAdd"].ToString());

                                            //        if (y2 > newY1)
                                            //        {
                                            //            y2 = 40;
                                            //            Freightflag = true;
                                            //        }
                                            //    }

                                            //    if (Freightflag == true)
                                            //        temp = temp + "\n" + p.readpdf(pdffilepath, newX1, newY1, newX2, y2, 2);
                                            //    else
                                            //        temp = temp + "\n" + p.readpdf(pdffilepath, newX1, newY1, newX2, y2, Convert.ToInt32(searchdt.Rows[index1]["PageNo"].ToString()));

                                            //}
                                            //else
                                            //{
                                            //    ///This else part is used for OCR the pages more than 2 pages.
                                            //    int currentOCRPage = MarksNoPage;

                                            //    while (currentOCRPage < FreightTermPage)
                                            //    {
                                            //        if (currentOCRPage == 1)
                                            //        {
                                            //            int newX1 = Convert.ToInt32(dr["x1"].ToString());

                                            //            //temp = temp + "\n" + p.readpdf(pdffilepath, newX1, newY1, newX2, y2, 2);
                                            //        }
                                            //        else
                                            //        {
                                            //            int newXX1 = Convert.ToInt32(dr["x1"].ToString());

                                            //            int newYY1 = 800;

                                            //            int newXX2 = Convert.ToInt32(dr["x2"].ToString());

                                            //            int newYY2 = 40;

                                            //            temp = temp + "\n" + p.readpdf(pdffilepath, newXX1, newYY1, newXX2, newYY2, currentOCRPage);
                                            //        }
                                            //        currentOCRPage++;
                                            //    }


                                            //    int newX1 = Convert.ToInt32(dr["x1"].ToString());

                                            //    //int newY1 = Convert.ToInt32(searchdt.Rows[NewPageTextIndex]["YCor"].ToString().Substring(0, searchdt.Rows[NewPageTextIndex]["YCor"].ToString().IndexOf(".")));
                                            //    int newY1 = 800;

                                            //    int newX2 = Convert.ToInt32(dr["x2"].ToString());

                                            //    int index1 = p.searchdt(searchdt, dr["y2"].ToString().Split('|'));

                                            //    bool Freightflag = false;
                                            //    if (index1 != -1)
                                            //    {
                                            //        y2 = (int)Convert.ToDouble(searchdt.Rows[index]["YCor"].ToString()) - (int)Convert.ToDouble(dr["LAdd"].ToString());

                                            //        if (y2 > newY1)
                                            //        {
                                            //            y2 = 40;
                                            //            Freightflag = true;
                                            //        }
                                            //    }

                                            //    if (Freightflag == true)
                                            //        temp = temp + "\n" + p.readpdf(pdffilepath, newX1, newY1, newX2, y2, 2);
                                            //    else
                                            //        temp = temp + "\n" + p.readpdf(pdffilepath, newX1, newY1, newX2, y2, currentOCRPage);

                                            //}

                                            #endregion
                                        }
                                        else
                                        {
                                            y2 = (int)Convert.ToDouble(searchdt.Rows[index]["YCor"].ToString()) - (int)Convert.ToDouble(dr["LAdd"].ToString());
                                        }
                                    }
                                    else
                                    {
                                        //   MessageBox.Show("Waït");
                                    }

                                }
                                else if (dr["T"].ToString() == "R")
                                {
                                    temp = p.searchdt_gettext(searchdt, dr["y2"].ToString().Split('|'), dr["LAdd"].ToString());
                                }
                                else if (dr["T"].ToString() == "C")
                                {
                                    temp = p.searchdt_gettext(searchdt, dr["y2"].ToString().Split('|'), dr["LAdd"].ToString().Split('|'));
                                }

                                if (temp == "")
                                {
                                    temp = p.readpdf(pdffilepath, x1, y1, x2, y2).Trim();
                                    //readpdf(pdffilepath, x1, y1, x2, y2);
                                    if (temp == "" && dr[0].ToString() == "B L No.")
                                    {
                                        temp = p.readpdf(pdffilepath, x1 + 50, y1 + 10, x2, y2 + 10).Trim();
                                    }

                                    if (temp.Contains("Reference No.") && dr[0].ToString() == "Reference No.")
                                    {
                                        string[] lines = temp.Split(new[] { "\r", "\n" }, StringSplitOptions.None);

                                        if (lines.Count() == 2)
                                        {
                                            foreach (string line in lines)
                                            {
                                                if (line.Contains("Reference No."))
                                                {
                                                    temp = line.Replace("Reference No.", "").Trim();
                                                    if (temp == "")
                                                        temp = "Missing Reference No";

                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }

                                if (temp == "")
                                {
                                    int index = p.searchdt(searchdt, dr["head"].ToString());
                                    if (index != -1)
                                    {
                                        x1 = (int)Convert.ToDouble(searchdt.Rows[index]["XCor"].ToString());
                                        y1 = (int)Convert.ToDouble(searchdt.Rows[index]["YCor"].ToString());
                                        temp = p.readpdf(pdffilepath, x1, y1, x2, y2).Trim().Replace(dr["head"].ToString(), "").Trim();
                                    }
                                }

                                if (dr["head"].ToString() == "HS CODE")
                                {
                                    if (temp.ToUpper().Contains("CODE"))
                                    {
                                        string[] descArry = temp.Split('\n');

                                        foreach (string arrayItem in descArry.Where(x => x.ToUpper().Contains("CODE")).Select(X => X))
                                        {
                                            temp = arrayItem.Substring(arrayItem.IndexOf("CODE") + 4).ToString().Trim().Replace(" ", "");
                                            temp = Regex.Replace(arrayItem, "[^0-9]", " ").Trim();
                                        }
                                    }
                                    else
                                    {
                                        try
                                        {
                                            if (temp[temp.Length - 1].ToString() == "T")
                                            {
                                                string chk = temp.Substring(0, temp.Length - 1);
                                                int ind = chk.LastIndexOf(' ') != -1 ? chk.LastIndexOf(' ') : 0;
                                                chk = chk.Substring(ind);
                                                chk = Regex.Replace(chk, "[^0-9]", " ").Trim();
                                                temp = chk;
                                            }
                                            else
                                            {
                                                string chk = temp;
                                                chk = chk.Substring(chk.LastIndexOf(' '));
                                                chk = Regex.Replace(chk, "[^0-9]", " ").Trim();
                                                temp = chk;
                                            }
                                        }
                                        catch { }
                                    }
                                }

                                if (dr["head"].ToString() == "Number of original Bs/L")
                                {
                                    temp = temp.Replace(@"/", " ").Replace("Three", "3").Replace("None", "0").Replace(" ", " ").Trim();
                                }

                                if (dr["head"].ToString().ToUpper() == "MEASUREMENT")
                                {
                                    if (!temp.ToUpper().Contains("CBM") && !temp.ToUpper().Contains("M3"))
                                    {
                                        temp = "";
                                    }
                                }

                                if (dr["head"].ToString() == "FileNo")
                                {
                                    temp = "";
                                    x1 = Convert.ToInt32(dr["x1"].ToString());
                                    y1 = Convert.ToInt32(dr["y1"].ToString());
                                    x2 = Convert.ToInt32(dr["x2"].ToString());
                                    y2 = Convert.ToInt32(dr["y2"].ToString());

                                    if (temp == "" && dr[0].ToString() == "FileNo")
                                    {
                                        temp = p.readpdf1(pdffilepath, x1, y1, x2, y2, 1).Trim();
                                        //drawRect(pdffilepath, x1, y1, x2, y2, 1);
                                        // temp = Regex.Match(temp, @"\d+").Value;
                                        temp = Regex.Replace(temp, @"[^A-Z]+", String.Empty);
                                    }

                                    dr_new["FileNo"] = temp;
                                }

                                if (dr["head"].ToString() == "FreightBill")
                                {
                                    temp = "";
                                    x1 = Convert.ToInt32(dr["x1"].ToString());
                                    y1 = Convert.ToInt32(dr["y1"].ToString());
                                    x2 = Convert.ToInt32(dr["x2"].ToString());
                                    y2 = Convert.ToInt32(dr["y2"].ToString());


                                    int pageNo = GetNoOfPages(pdffilepath);

                                    bool shippedOnBoardFlag = false;
                                    while (pageNo > 0 && dr[0].ToString() == "FreightBill")
                                    {
                                        temp = p.readpdf1(pdffilepath, x1, y1, x2, y2, pageNo).Trim();

                                        if (temp.ToUpper().Contains("SHIPPED ON BOARD"))
                                        {
                                            shippedOnBoardFlag = true;
                                            break;
                                        }
                                        pageNo = pageNo - 1;
                                    }

                                    //temp = p.readpdf1(pdffilepath, x1, y1, x2, y2, 1).Trim();
                                    //// temp = Regex.Match(temp, @"\d+").Value;

                                    //if (!temp.Contains("SHIPPED ON BOARD"))
                                    //{
                                    //    temp = temp + p.readpdf1(pdffilepath, x1, y1, x2, y2, 2).Trim();
                                    //    if (!temp.Contains("SHIPPED ON BOARD"))
                                    //    {
                                    //        temp = temp + p.readpdf1(pdffilepath, x1, y1, x2, y2, 3).Trim();
                                    //    }
                                    //}

                                    if (shippedOnBoardFlag == true)
                                        dr_new["FreightBill"] = p.readpdf1(pdffilepath, x1, y1, x2, y2, pageNo).Trim();
                                }

                                dr_new[dr["head"].ToString()] = temp.Replace(dr["head"].ToString(), "").Trim();
                            }
                        }

                        dr_new["FilePath"] = System.IO.Path.GetFileName(pdffilepath);

                        ///07/25/2018
                        /// Saving of all Scanned PDF Data is decided to stop as validation process takes time due too much data in table.
                        /// 

                        //Random r = new Random();
                        //string key = DateTime.Now.ToShortDateString().ToString() + r.Next().ToString();

                        //db_Europe_ValidationDataSetTableAdapters.QueriesTableAdapter q = new db_Europe_ValidationDataSetTableAdapters.QueriesTableAdapter();
                        //foreach (DataRow search_dr in searchdt.Rows)
                        //{
                        //    q.Sp_Insert_PDFData(dr_new[0].ToString(), search_dr[0].ToString(), search_dr[1].ToString(), search_dr[2].ToString(), Convert.ToInt32(search_dr["PageNo"].ToString()), key);
                        //}

                        bool flag = false;
                        foreach (DataRow dr_exists in dt.Rows)
                        {
                            if (dr_new[0].ToString() == dr_exists[0].ToString() && dr_new["ErrorDetails"].ToString() == dr_exists["ErrorDetails"].ToString())
                            {
                                flag = true;
                            }
                            else if (dr_new[0].ToString() == dr_exists[0].ToString() && dr_new["ErrorDetails"].ToString() != dr_exists["ErrorDetails"].ToString())
                            {
                                dr_exists.Delete();
                                break;
                            }

                        }
                        if (flag == false)
                        {
                            dt.Rows.Add(dr_new);
                           // runvalidation(dr_new);
                            //dg_output.DataSource = dt;
                            //dg_output.Columns["ErrorDetails"].Visible = false;
                            //dg_output.Refresh();
                          //  insert_data(dr_new);
                        }
                        else
                        {
                            try
                            {
                                //if (!File.Exists(duplicatepath + dr_new["FilePath"].ToString()))
                                //{
                                //    System.IO.File.Move(pdffilepath, duplicatepath + dr_new["FilePath"].ToString());
                                //}
                                //else
                                //{
                                //    System.IO.File.Delete(sourcepath + dr_new["FilePath"].ToString());
                                //}
                            }
                            catch
                            { }
                        }
                    }
                    //    txt_error.Text = dg_output.Rows[0].Cells["ErrorDetails"].Value.ToString();

                }

               // return dt;
            }
            catch (Exception ex)
            {

            }
            return dt;
        }
        public int GetNoOfPages(string filepath)
        {
            int PageCount = 0;
            try
            {
                PdfReader pdfReader = new PdfReader(filepath);

                PageCount = pdfReader.NumberOfPages;
            }
            catch (Exception ex)
            {

            }
            return PageCount;
        }
        
        public void restructure()
        {
            string currentDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);

            dt_structure = t.readfile(currentDir + "\\template.tformat");
            DataTable dt_new = new DataTable();
            dt = dt_new;
            foreach (DataRow dr in dt_structure.Rows)
            {
                dt.Columns.Add(dr["head"].ToString());
            }
            dt.Columns.Add("FilePath");
            dt.Columns.Add("ErrorDetails");
            //dg_output.DataSource = "";
            //dg_output.DataSource = dt;
            //dg_output.Columns["ErrorDetails"].Visible = true;
            ////dg_output.Columns["FilePath"].CellTemplate = new DataGridViewButtonCell();
            //dg_output.Refresh();
        }

        public void getall()
        {
            //using (SQlConnection)
            //{

            //}
        }
        //public void runvalidation(DataRow dr)
        //{
        //    try
        //    {
        //        txt_error.Text = "";
        //        DataTable pdfsearchdt = p.searchpdf(pdffilepath);
        //        //foreach (DataGridViewRow dr in dg_output.Rows)

        //        string countryname = "";
        //        DataTable sp_GetCountry_dt = new DataTable();
        //        db_Europe_ValidationDataSetTableAdapters.Sp_GetCountryTableAdapter sp_GetCountryTableAdapter = new db_Europe_ValidationDataSetTableAdapters.Sp_GetCountryTableAdapter();
        //        db_Europe_ValidationDataSet.Sp_GetCountryDataTable sp_GetCountry_dt = new db_Europe_ValidationDataSet.Sp_GetCountryDataTable();
        //        sp_GetCountryTableAdapter.Fill(sp_GetCountry_dt, dr["B L No."].ToString().Substring(4, 3));
        //        dr["ErrorDetails"] = "";
        //        db_Europe_ValidationDataSet.Sp_Select_PDFDataTable newSearchDt = new db_Europe_ValidationDataSet.Sp_Select_PDFDataTable();
        //        db_Europe_ValidationDataSetTableAdapters.Sp_Select_PDFTableAdapter sp_Select_PDFTableAdapter = new db_Europe_ValidationDataSetTableAdapters.Sp_Select_PDFTableAdapter();
        //        sp_Select_PDFTableAdapter.Fill(newSearchDt, dr["B L No."].ToString());

        //        db_Europe_ValidationDataSetTableAdapters.Sp_GetIATATableAdapter sp_GetIATATableAdapter = new db_Europe_ValidationDataSetTableAdapters.Sp_GetIATATableAdapter();
        //        db_Europe_ValidationDataSet.Sp_GetIATADataTable sp_GetIATADataTable = new db_Europe_ValidationDataSet.Sp_GetIATADataTable();

        //        //db_Europe_ValidationDataSetTableAdapters.Sp_GetIATATableAdapter sp_GetIATAtableAdaptor = new db_Europe_ValidationDataSetTableAdapters.Sp_GetIATATableAdapter();
        //        //db_Europe_ValidationDataSet.Sp_GetIATADataTable sp_GEtIATA = new db_Europe_ValidationDataSet.Sp_GetIATADataTable();
        //        //sp_GetIATAtableAdaptor.Fill(sp_GEtIATA, dr["Freight payable at"].ToString());


        //        //foreach(DataRow xr in sp_GEtIATA)
        //        //{
        //        //    string FrieghPortname = xr["IATA"].ToString();
        //        //}

        //       // sp_GetCountry_dt=

        //        dr["POD"] = (dr["POD"].ToString().Contains("\n") ? dr["POD"].ToString().Substring(0, dr["POD"].ToString().IndexOf("\n")) : dr["POD"].ToString());

        //        if (sp_GetCountry_dt.Rows.Count != 0)
        //        {
        //            if (sp_GetCountry_dt.Rows[0][0].ToString() == "U.S.A.")
        //            {
        //                countryname = "US";
        //            }
        //            else if (sp_GetCountry_dt.Rows[0][0].ToString() == "CANADA")
        //            {
        //                countryname = "CANADA";
        //            }
        //            else if (sp_GetCountry_dt.Rows[0][0].ToString() == "INDIA")
        //            {
        //                countryname = "INDIA";
        //            }
        //            else if (sp_GetCountry_dt.Rows[0][0].ToString() == "FRANCE")
        //            {
        //                countryname = "FRANCE";
        //            }
        //            else if (sp_GetCountry_dt.Rows[0][0].ToString() == "MEXICO")
        //            {
        //                countryname = "MEXICO";
        //            }
        //            else if (sp_GetCountry_dt.Rows[0][0].ToString() == "BRAZIL")
        //            {
        //                countryname = "BRAZIL";
        //            }
        //            else if (sp_GetCountry_dt.Rows[0][0].ToString() == "ITALY")
        //            {
        //                countryname = "ITALY";
        //            }
        //            else if (sp_GetCountry_dt.Rows[0][0].ToString() == "BELGIUM")
        //            {
        //                countryname = "BELGIUM";
        //            }
        //            else if (sp_GetCountry_dt.Rows[0][0].ToString() == "CHINA")
        //            {
        //                countryname = "CHINA";
        //            }
        //            else if (sp_GetCountry_dt.Rows[0][0].ToString() == "PAKISTAN")
        //            {
        //                countryname = "PAKISTAN";
        //            }
        //            else
        //            {
        //                countryname = sp_GetCountry_dt.Rows[0][0].ToString();
        //            }
        //        }

        //        ///10 DEC 2019 ADDED BY RAHUL WAGHCHAURE
        //        ///

        //        if (countryname == "INDONESIA" || countryname == "VIETNAM" || countryname == "PERU" || countryname == "BOLIVIA" || countryname == "PUERTO RICO" || countryname == "PUERTO RICO" || dr["POD"].ToString().ToUpper().Trim() == "IQUIQUE VIA ARICA")
        //        {
        //            if (dr["B L No."].ToString().Trim().Substring(0, 3) != "MIL" && countryname != "CHILE")
        //            {
        //                //if ((!dr["Consignee"].ToString().ToUpper().Contains("TAX")
        //                //&& !dr["ConsigneeAddress"].ToString().ToUpper().Contains("TAX")
        //                //&& !dr["Notify"].ToString().ToUpper().Contains("TAX")
        //                //&& !dr["NotifyAddress"].ToString().ToUpper().Contains("TAX"))
        //                //&& (!dr["Consignee"].ToString().ToUpper().Contains("VAT")
        //                //&& !dr["ConsigneeAddress"].ToString().ToUpper().Contains("VAT")
        //                //&& !dr["Notify"].ToString().ToUpper().Contains("VAT")
        //                //&& !dr["NotifyAddress"].ToString().ToUpper().Contains("VAT"))
        //                //&& (!dr["Consignee"].ToString().ToUpper().Contains("RUC")
        //                //&& !dr["ConsigneeAddress"].ToString().ToUpper().Contains("RUC")
        //                //&& !dr["Notify"].ToString().ToUpper().Contains("RUC")
        //                //&& !dr["NotifyAddress"].ToString().ToUpper().Contains("RUC"))
        //                //&& (!dr["Consignee"].ToString().ToUpper().Contains("TVA")
        //                //&& !dr["ConsigneeAddress"].ToString().ToUpper().Contains("TVA")
        //                //&& !dr["Notify"].ToString().ToUpper().Contains("TVA")
        //                //&& !dr["NotifyAddress"].ToString().ToUpper().Contains("TVA"))
        //                //&& (!dr["Consignee"].ToString().ToUpper().Contains("MRN")
        //                //&& !dr["ConsigneeAddress"].ToString().ToUpper().Contains("MRN")
        //                //&& !dr["Notify"].ToString().ToUpper().Contains("MRN")
        //                //&& !dr["NotifyAddress"].ToString().ToUpper().Contains("MRN"))
        //                //)

        //                if (!checkTAXCODE(dr["Consignee"].ToString().ToUpper(), dr["ConsigneeAddress"].ToString().ToUpper())
        //                    && !checkTAXCODE(dr["Notify"].ToString().ToUpper(), dr["NotifyAddress"].ToString().ToUpper()))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- CONSIGNEE + NOTIFY -TAX /VAT/RUC/TVA/MRN codes are required for CONSIGNEE + NOTIFY -TAX /VAT/RUC/TVA/MRN\r\n";
        //                }
        //            }

        //        }


        //        if (dr["POD"].ToString().ToUpper().Contains("CALLAO")
        //            || dr["POD"].ToString().ToUpper().Contains("VALPARAISO")
        //            || dr["POD"].ToString().ToUpper().Contains("SAN ANTONIO")
        //            || dr["POD"].ToString().ToUpper().Contains("BUENOS ARIES")
        //            || dr["POD"].ToString().ToUpper().Contains("BUENAVENTURA ")
        //            || dr["POD"].ToString().ToUpper().Contains("CARTAGENA")
        //            || dr["POD"].ToString().ToUpper().Contains("HAIPHONG")
        //            || dr["POD"].ToString().ToUpper().Contains("HO CHI MINH PHUOC LONG")
        //            || dr["POD"].ToString().ToUpper().Contains("VERA CRUZ")
        //            || dr["POD"].ToString().ToUpper().Contains("ASHDOD")
        //            || dr["POD"].ToString().ToUpper().Contains("HAIFA")
        //            || dr["POD"].ToString().ToUpper().Contains("ALGER")
        //            || dr["POD"].ToString().ToUpper().Contains("ORAN")
        //            || dr["POD"].ToString().ToUpper().Contains("BEJAIA")
        //            || dr["POD"].ToString().ToUpper().Contains("ISTANBUL")
        //            || dr["POD"].ToString().ToUpper().Contains("RIO DE JANEIRO")
        //            || dr["POD"].ToString().ToUpper().Contains("RIO GRANDE")
        //            || dr["POD"].ToString().ToUpper().Contains("HUANGPU")
        //            || dr["POD"].ToString().ToUpper().Contains("OLD PORT VIA HONG KONG")
        //            || dr["POD"].ToString().ToUpper().Contains("DALIAN")
        //            || dr["POD"].ToString().ToUpper().Contains("QINGDAO")
        //            || dr["POD"].ToString().ToUpper().Contains("SHANGHAI")
        //            || dr["POD"].ToString().ToUpper().Contains("XINGANG")
        //            || dr["POD"].ToString().ToUpper().Contains("JAKARTA")
        //            || dr["POD"].ToString().ToUpper().Contains("SURABAYA")
        //            || countryname == "BRAZIL"
        //            || countryname == "MEXICO")
        //        {
        //            if (dr["B L No."].ToString().Trim().Substring(0, 3) != "MIL" && countryname != "CHILE")
        //            {
        //                //if ((!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("RFC")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("R.F.C")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CUIT")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("VAT")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("TAX")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("USCI")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("RUC")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("ATA")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("RUT")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("NIT")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CDMX")
        //                //&& !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("NIF")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("RFC")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("R.F.C")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("CUIT")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("VAT")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("TAX")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("USCI")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("RUC")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("ATA")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("RUT")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("NIT")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("CDMX")
        //                //&& !dr["Consignee"].ToString().Trim().ToUpper().Contains("NIF")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("RFC")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("R.F.C")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CUIT")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("VAT")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("TAX")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("USCI")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("RUC")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("ATA")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("RUT")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("NIT")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CDMX")
        //                //&& !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("NIF")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("RFC")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("R.F.C")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("CUIT")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("VAT")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("TAX")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("USCI")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("RUC")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("ATA")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("RUT")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("NIT")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("CDMX")
        //                //&& !dr["Notify"].ToString().Trim().ToUpper().Contains("NIF")))
        //                if (!checkTAXCODE(dr["Consignee"].ToString().ToUpper(), dr["ConsigneeAddress"].ToString().ToUpper())
        //                    && !checkTAXCODE(dr["Notify"].ToString().ToUpper(), dr["NotifyAddress"].ToString().ToUpper()))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- CONSIGNEE + NOTIFY -R.F.C./RUT/DESCONSOLIDADOR/NIT/CUIT/RFC/TAX/VAT/CDMX/CNPJ/USCI codes are required\r\n";
        //                }
        //            }
        //        }




        //        ///05/08/2018
        //        /// Shipper and Consignee should not be same
        //        /// 05/29/2018
        //        /// Condition changed on request. Now Address also will get checked whether they are same or not for consignee and shipper field.
        //        if ((dr["Shipper"].ToString().Trim().ToUpper() == dr["Consignee"].ToString().Trim().ToUpper()) && (dr["ShipperAddress"].ToString().Trim().ToUpper() == dr["ConsigneeAddress"].ToString().Trim().ToUpper()))
        //        {
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Shipper's Name/Address and Consignee's Name/Address can not be same\r\n";
        //        }

        //        ///05/08/2018
        //        /// Volume should not be blank
        //        if (dr["Measurement"].ToString().Trim().ToUpper() == "")
        //        {
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Volume can not be blank\r\n";
        //        }

        //        ///05/08/2018
        //        /// Volume except for DHL and JAS should be greater than 1.00
        //        if (dr["Measurement"].ToString().Trim().ToUpper() != "")
        //        {
        //            if ((dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //                && (!dr["Consignee"].ToString().ToUpper().Contains("DHL") || !dr["Consignee"].ToString().ToUpper().Contains("JAS")))
        //            {
        //                if (dr["Measurement"].ToString().ToUpper().Contains("CBM"))
        //                {
        //                    if ((Convert.ToDecimal(dr["Measurement"].ToString().ToUpper().Replace("CBM", "").Replace(",", "").Trim()) < 1) && (!dr["Pre carriage by"].ToString().ToUpper().Trim().Contains("TRUCK")))
        //                    {
        //                        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Volume should be greater than 1\r\n";
        //                    }
        //                }
        //            }
        //        }



        //        if (dr["Measurement"].ToString().Trim().ToUpper() != "")
        //        {
        //            if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //            {
        //                if (!dr["Measurement"].ToString().ToUpper().Contains("CBM"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Volume can not be blank\r\n";
        //                }
        //            }
        //        }


        //        ///05/08/2018
        //        /// RFC/CNPJ/CUIT/ATA/RUC/RUT  Number - For required port should not be miss in Consignee field 

        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //        {
        //            //if ((!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("RFC")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("R.F.C")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CNPJ")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CUIT")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("TAX")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("USCI")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("RUC")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("ATA")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("RFC")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("R.F.C")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("CNPJ")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("CUIT")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("VAT")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("TAX")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("USCI")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("RUC")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("ATA")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("RFC")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("R.F.C")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CNPJ")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CUIT")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("VAT")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("TAX")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("USCI")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("RUC")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("ATA")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("RFC")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("R.F.C")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("CNPJ")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("CUIT")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("VAT")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("TAX")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("USCI"))
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("RUC")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("ATA")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")

        //            if (!checkTAXCODE(dr["Consignee"].ToString().ToUpper(), dr["ConsigneeAddress"].ToString().ToUpper())
        //                    && !checkTAXCODE(dr["Notify"].ToString().ToUpper(), dr["NotifyAddress"].ToString().ToUpper())
        //                && (dr["POD"].ToString().ToUpper().Contains("MEXICO")
        //                //|| dr["POD"].ToString().ToUpper().Contains("ALTAMIRA")
        //                || dr["POD"].ToString().ToUpper().Contains("RIO GRANDE")
        //                || dr["POD"].ToString().ToUpper().Contains("SANTOS")
        //                || dr["POD"].ToString().ToUpper().Contains("CALLAO")
        //                || dr["POD"].ToString().ToUpper().Contains("BUENOS AIRES")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Consignee OR notify party field should contain RFC/R.F.C/CNPJ/CUIT/VAT/TAX/USCI/RUC/ATA/DESCONSOLIDADOR  Number for Mexico, RIO GRANDE,SANTOS,CALLAO,Buenos Aires. \r\n";
        //            }
        //        }
        //        ///05/08/2018
        //        /// RFC/CNPJ/CUIT/ATA/RUC/RUT  Number - should not be there in Marks and no. and good description for given ports only.

        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //        {
        //            if ((dr["Marks Nos"].ToString().Trim().ToUpper().Contains(" RFC")
        //            || dr["Marks Nos"].ToString().Trim().ToUpper().Contains(" R.F.C")
        //            || dr["Marks Nos"].ToString().Trim().ToUpper().Contains(" CNPJ")
        //            || dr["Marks Nos"].ToString().Trim().ToUpper().Contains(" CUIT")
        //            || dr["Marks Nos"].ToString().Trim().ToUpper().Contains(" VAT")
        //            || dr["Marks Nos"].ToString().Trim().ToUpper().Contains(" TAX")
        //            || dr["Marks Nos"].ToString().Trim().ToUpper().Contains(" USCI")
        //            || dr["Marks Nos"].ToString().Trim().ToUpper().Contains(" RUC")
        //            || dr["Marks Nos"].ToString().Trim().ToUpper().Contains(" ATA")
        //            || dr["Marks Nos"].ToString().Trim().ToUpper().Contains(" DESCONSOLIDADOR")
        //            || dr["Description"].ToString().Trim().ToUpper().Contains(" RFC")
        //            || dr["Description"].ToString().Trim().ToUpper().Contains(" R.F.C")
        //            || dr["Description"].ToString().Trim().ToUpper().Contains(" CNPJ")
        //            || dr["Description"].ToString().Trim().ToUpper().Contains(" CUIT")
        //            || dr["Description"].ToString().Trim().ToUpper().Contains(" VAT")
        //            || dr["Description"].ToString().Trim().ToUpper().Contains(" TAX")
        //            || dr["Description"].ToString().Trim().ToUpper().Contains(" USCI")
        //            || dr["Description"].ToString().Trim().ToUpper().Contains(" RUC")
        //            || dr["Description"].ToString().Trim().ToUpper().Contains(" ATA")
        //            || dr["Description"].ToString().Trim().ToUpper().Contains(" DESCONSOLIDADOR"))
        //            && (dr["POD"].ToString().ToUpper().Contains("MEXICO")
        //            //|| dr["POD"].ToString().ToUpper().Contains("ALTAMIRA")
        //            || dr["POD"].ToString().ToUpper().Contains("RIO GRANDE")
        //            || dr["POD"].ToString().ToUpper().Contains("SANTOS")
        //            || dr["POD"].ToString().ToUpper().Contains("CALLAO")
        //            || dr["POD"].ToString().ToUpper().Contains("BUENOS AIRES")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Description field should not contain RFC/CNPJ/CUIT/VAT/TAX/USCI/RUC/ATA/DESCONSOLIDADOR Number. \r\n";
        //            }



        //        }
        //        ///05082018
        //        /// NIT # should be there in Consignee or Notify Party for Cartagena Port
        //        if (!(dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL"))
        //        {
        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("CARTAGENA")
        //                && ((!dr["Consignee"].ToString().ToUpper().Contains("NIT")
        //                && !dr["ConsigneeAddress"].ToString().ToUpper().Contains("NIT")
        //                && !dr["Notify"].ToString().ToUpper().Contains("NIT")
        //                && !dr["NotifyAddress"].ToString().ToUpper().Contains("NIT"))
        //                && (!dr["Consignee"].ToString().ToUpper().Contains("VAT")
        //                && !dr["ConsigneeAddress"].ToString().ToUpper().Contains("VAT")
        //                && !dr["Notify"].ToString().ToUpper().Contains("VAT")
        //                && !dr["NotifyAddress"].ToString().ToUpper().Contains("VAT"))
        //                && (!dr["Consignee"].ToString().ToUpper().Contains("TAX")
        //                && !dr["ConsigneeAddress"].ToString().ToUpper().Contains("TAX")
        //                && !dr["Notify"].ToString().ToUpper().Contains("TAX")
        //                && !dr["NotifyAddress"].ToString().ToUpper().Contains("TAX"))
        //                && (!dr["Consignee"].ToString().ToUpper().Contains("RUT")
        //                && !dr["ConsigneeAddress"].ToString().ToUpper().Contains("RUT")
        //                && !dr["Notify"].ToString().ToUpper().Contains("RUT")
        //                && !dr["NotifyAddress"].ToString().ToUpper().Contains("RUT"))))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- NIT # or VAT # or TAX # or RUT # should be there in Consignee or Notify Party for Cartagena Port. \r\n";
        //            }
        //        }
        //        ///05082018
        //        /// NIF # should be there in Consignee or Notify Party
        //        /// 

        //        if (dr["POD"].ToString().Trim().ToUpper().Contains("ALGER")
        //            && (!dr["Consignee"].ToString().ToUpper().Contains("NIF")
        //            && !dr["ConsigneeAddress"].ToString().ToUpper().Contains("NIF")
        //            && !dr["Notify"].ToString().ToUpper().Contains("NIF")
        //            && !dr["NotifyAddress"].ToString().ToUpper().Contains("NIF")
        //            && !dr["FreightBill"].ToString().ToUpper().Contains("NIF")))
        //        {
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- NIF # should be there in Consignee or Notify Party for ALGER Port. \r\n";
        //        }

        //        //
        //        ///Commneted on 12/12/2019 on request of bharat patil. as if user doesnt affect if HS code is taken or not
        //        ///
        //        //if (dr["POD"].ToString().Trim().ToUpper().Contains("CARTAGENA") && dr["Description"].ToString().ToUpper().Contains("CODE"))
        //        //{
        //        //    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General --% # HS Code Not Mandatory. \r\n";
        //        //}

        //        ///NCM number should be in Good description.
        //        ///

        //        ///Previously it is added only for Italy region. However, as per instruction from Nilesh C. Jadhav moved this validation for all regions.
        //        ///on 09/26/2019

        //        //if (!dr["Description"].ToString().Contains("NCM") && (dr["POD"].ToString().Trim().ToUpper().Contains("SANTOS") || dr["POD"].ToString().Trim().ToUpper().Contains("RIO DE JANEIRO") || dr["POD"].ToString().Trim().ToUpper().Contains("RIO GRANDE") || dr["POD"].ToString().Trim().ToUpper().Contains("BUENOS AIRES")))
        //        //{
        //        //    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- NCM # should be there in GOOD DESCRIPTION for SANTOS / RIO DE JANEIRO/RIO GRANDE and BUENOS AIRES. \r\n";
        //        //}
        //        //else if (!dr["Description"].ToString().Contains("HS CODE"))
        //        //{
        //        //    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- HS CODE # should be there in GOOD DESCRIPTION ";

        //        //}

        //        ///08212018
        //        /// Mail by Bharat Patil on Mon 8/20/2018 3:12 PM
        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //        {
        //            ///// for ITALY POL, NCM # is mandatory.
        //            //if (!dr["Description"].ToString().Contains("NCM"))
        //            //{
        //            //    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- NCM # IS REQUIRED FOR BUENOS AIRES \r\n";
        //            //}

        //            if (dr["POD"].ToString().Trim().ToUpper().Trim().ToUpper().Contains("CASABLANCA"))
        //            {
        //                if (dr["Consignee"].ToString().ToUpper().Contains("COPIMA") && !dr["BL Type"].ToString().ToUpper().Contains("EXPRESS"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "If consignee is COPIMA then in body bl Express bl should be captured by user.\r\n";
        //                }
        //            }

        //            ///added as per mail from Bharat patil on Tue 9/3/2019 3:33 PM
        //            ///
        //            if (dr["Consignee"].ToString().ToUpper().Contains("GULF CRAFT") && dr["BL Type"].ToString().ToUpper().Contains("EXPRESS"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "If consignee is GULF CRAFT then in body bl Express bl should not be captured by user.\r\n";
        //            }
        //            // if POD is LUANDA and  BL Type Express and  B L No in MIL Region for ITALY
        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("LUANDA") && dr["BL Type"].ToString().ToUpper().Contains("EXPRESS") && dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "If POD is LUANDA then BL Type should not be Express bl.\r\n";
        //            }

        //            if ((dr["Consignee"].ToString().ToUpper().Contains("HAROON") || dr["Notify"].ToString().ToUpper().Contains("HAROON")) && dr["POD"].ToString().Trim().ToUpper().Contains("DUBAI") && (!dr["BL Type"].ToString().ToUpper().Contains("ORIGINAL")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "For DUBAI port AND HAROON CONSIGNEE Original BL is Mandatory";
        //            }

        //            //if (dr["POD"].ToString().Trim().ToUpper().Contains("LUANDA") && !dr["BL Type"].ToString().ToUpper().Contains("EXPRESS"))
        //            //{
        //            //    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "If POD is LUanda then BL Type should be Express bl.\r\n";
        //            //}

        //            ///Updated by RAHUL ON 18-DEC-2019 AS PER CONFIMRATION FROM BHARAT PATIL-  Wed 12/18/2019 3:16 PM
        //            ///
        //            if ((dr["POD"].ToString().Trim().ToUpper().Contains("ASHDOD") || dr["POD"].ToString().Trim().ToUpper().Contains("HAIFA")) && (dr["Consignee"].ToString().ToUpper().Contains("PALESTIN") || dr["Notify"].ToString().ToUpper().Contains("PALESTIN") || dr["ConsigneeAddress"].ToString().ToUpper().Contains("PALESTIN") || dr["NotifyAddress"].ToString().ToUpper().Contains("PALESTIN")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "If POD is ASHDOD and consignee/notify contains PALESTINE then highlight same to front office.\r\n";
        //            }

        //            ///05082018
        //            /// VAT # should be there in Consignee or Notify Party for DUBAI AND ASHDOD Port.
        //            if (((dr["POD"].ToString().Trim().ToUpper().Contains("DUBAI")
        //                && (dr["PLD"].ToString().Trim().ToUpper().Contains("ABU DHABI")
        //                    || dr["PLD"].ToString().Trim().ToUpper().Contains("AJMAN")
        //                    || dr["PLD"].ToString().Trim().ToUpper().Contains("FUJAIRAH")
        //                    || dr["PLD"].ToString().Trim().ToUpper().Contains("RAS AL-KHAIMA")
        //                    || dr["PLD"].ToString().Trim().ToUpper().Contains("SHARJA E UMM AL-QAYWAYN")
        //                    || dr["PLD"].ToString().Trim() == ""))
        //                        || dr["POD"].ToString().Trim().ToUpper().Contains("ASHDOD"))
        //                        && (!dr["Consignee"].ToString().ToUpper().Contains("VAT")
        //                            && !dr["Notify"].ToString().ToUpper().Contains("VAT")
        //                            && !dr["ConsigneeAddress"].ToString().ToUpper().Contains("VAT")
        //                            && !dr["NotifyAddress"].ToString().ToUpper().Contains("VAT")
        //                            && !dr["Consignee"].ToString().ToUpper().Contains("TAX")
        //                            && !dr["Notify"].ToString().ToUpper().Contains("TAX")
        //                            && !dr["ConsigneeAddress"].ToString().ToUpper().Contains("TAX")
        //                            && !dr["NotifyAddress"].ToString().ToUpper().Contains("TAX")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- VAT # should be there in Consignee or Notify Party for DUBAI AND ASHDOD Port. \r\n";
        //            }
        //            ///Place of receipt Always MILAN
        //            if (dr["PLR"].ToString() != "MILAN" && dr["PLR"].ToString() != "KOPER")
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Place of Receipt should be always MILAN for Italy. \r\n";
        //            }

        //            ///For Bollore shipper -shipper ref number should be start with 47100
        //            if (dr["Shipper"].ToString().Contains("BOLLORE") && !(dr["Reference No."].ToString().Trim().Substring(0, 5) == "47100"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Reference # should be start with 47100 for BOLLORE SHIPER. \r\n";
        //            }

        //            ///TAX ID should be in Consignee field for JAKARTA PORT
        //            if ((dr["POD"].ToString().Trim().ToUpper().Contains("JAKARTA"))
        //                && ((!dr["ConsigneeAddress"].ToString().ToUpper().Contains("TAX"))
        //                && (!dr["ConsigneeAddress"].ToString().ToUpper().Contains("NPWP"))
        //                && (!dr["Consignee"].ToString().ToUpper().Contains("TAX"))
        //                && (!dr["Consignee"].ToString().ToUpper().Contains("NPWP"))))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- TAX ID / NPWP should be mentioned for JAKARTA PORT in consignee field. \r\n";
        //            }

        //            ///GSTN NUMBER -19AABCT0704G1Z0 SHOULD BE THERE FOR TIL LIMITED CALCUTTA INDIA  IN CONSIGNEE FIELD
        //            if ((dr["POD"].ToString().Trim().ToUpper().Contains("CALCUTTA") || dr["PLD"].ToString().Trim().ToUpper().Contains("CALCUTTA")) && (dr["Consignee"].ToString().ToUpper().Contains("TIL LIMITED")) && (!dr["ConsigneeAddress"].ToString().Contains("GSTN")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- GSTN # should be mentioned for CALCUTTA PORT in consignee field of TIL LIMITED. \r\n";
        //            }

        //            ///EMAIL :RAJAT.MONDAL@TILINDIA.COM SHOULD BE THERE FOR TIL LIMITED CALCUTTA INDIA IN CONSIGNEE FIELD
        //            if ((dr["POD"].ToString().Trim().ToUpper().Contains("CALCUTTA") || dr["PLD"].ToString().Trim().ToUpper().Contains("CALCUTTA")) && (dr["Consignee"].ToString().ToUpper().Contains("TIL LIMITED")) && (!dr["ConsigneeAddress"].ToString().Contains("RAJAT.MONDAL@TILINDIA.COM")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- EMAIL :RAJAT.MONDAL@TILINDIA.COM should be mentioned for CALCUTTA PORT in consignee field of TIL LIMITED. \r\n";
        //            }

        //            ///IEC NUMBER :0288017625 SHOULD BE THERE FOR TIL LIMITED CALCUTTA INDIA IN CONSIGNEE FIELD
        //            /// 
        //            if ((dr["POD"].ToString().Trim().ToUpper().Contains("CALCUTTA") || dr["PLD"].ToString().Trim().ToUpper().Contains("CALCUTTA")) && (dr["Consignee"].ToString().ToUpper().Contains("TIL LIMITED")) && (!dr["ConsigneeAddress"].ToString().Contains("0288017625")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- IEC NUMBER :0288017625 should be mentioned for CALCUTTA PORT in consignee field of TIL LIMITED. \r\n";
        //            }

        //            ///For Abidjan port always capture in Marks & Number Gross weight should be capture 
        //            /// 
        //            if ((dr["POD"].ToString().Trim().ToUpper().Contains("ABIDJAN")) && (dr["Weight"].ToString() == ""))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Weight should be mentioned for ABIDJAN PORT. \r\n";
        //            }

        //            ///For Truck file in "Pre-carriage by "fields always have to mention "Truck" & Port of loading should be "ANTWERP"
        //            /// 
        //            if (((dr["Pre carriage by"].ToString() == "TRUCK") && (dr["POL"].ToString() != "ANTWERP")) || ((dr["Pre carriage by"].ToString() != "TRUCK") && (dr["POL"].ToString() == "ANTWERP")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "For Truck file in 'Pre-carriage by' fields always have to mention 'Truck' & Port of loading should be b'ANTWERP'";
        //            }

        //            ///For GUAYAQUIL port  Original BL is Mandatory
        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("GUAYAQUIL") && (!dr["BL Type"].ToString().ToUpper().Contains("ORIGINAL")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "For GUAYAQUIL port  Original BL is Mandatory";
        //            }

        //            ///HS CODE OR CUSTOM TARIFF SHOULD MENTIONED IN GOODS DESCRIPTION FOR AQUABA, HAMAD POD.
        //            /// 
        //            if ((dr["POD"].ToString().Trim().ToUpper().Contains("AQABA") || dr["POD"].ToString().Trim().ToUpper().Contains("HAMAD")) && (!checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString()) && !dr["Description"].ToString().Contains("Custom Traiff") && !dr["Description"].ToString().Trim().ToUpper().Contains("CODE")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- HS CODE OR CUSTOM TARIFF SHOULD MENTIONED IN GOODS DESCRIPTION FOR AQUABA, HAMAD POD. \r\n";
        //            }

        //            if ((dr["POD"].ToString().Trim().ToUpper().Contains("LIMASSOL")) && (!checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString())))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- HS CODE SHOULD MENTIONED IN GOODS DESCRIPTION FOR LIMASSOL POD. \r\n";
        //            }

        //            ///PH :61 3 9399 8957 SHOULD BE THERE FOR HYDRAULICS NETWORK PTY LTD IN CONSIGNEE FIELD FOR MELBOURNE
        //            /// 
        //            if ((dr["POD"].ToString().Contains("MELBOURNE")) && (dr["Consignee"].ToString().ToUpper().Contains("HYDRAULICS NETWORK PTY LTD") || dr["Notify"].ToString().ToUpper().Contains("HYDRAULICS NETWORK PTY LTD") || dr["Notify"].ToString().ToUpper().Contains("SAME AS CONSIGNEE")) && (!dr["ConsigneeAddress"].ToString().Contains("61 3 9399") && !dr["ConsigneeAddress"].ToString().Contains("8957") && !dr["NotifyAddress"].ToString().Contains("61 3 9399") && !dr["NotifyAddress"].ToString().Contains("8957")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Phone # should be mentioned for MELBOURNE PORT in consignee field of HYDRAULICS NETWORK PTY LTD. \r\n";
        //            }

        //            ///eMAIL :matt@hydraulicsnetwork.com.au SHOULD BE THERE FOR HYDRAULICS NETWORK PTY LTD IN CONSIGNEE FIELD FOR MELBOURNE
        //            /// 
        //            if ((dr["POD"].ToString().Contains("MELBOURNE")) && (dr["Consignee"].ToString().ToUpper().Contains("HYDRAULICS NETWORK PTY LTD") || dr["Notify"].ToString().ToUpper().Contains("HYDRAULICS NETWORK PTY LTD") || dr["Notify"].ToString().ToUpper().Contains("SAME AS CONSIGNEE")) && (!dr["ConsigneeAddress"].ToString().Contains("chris@hydraulicsnetwork.com.au") && !dr["NotifyAddress"].ToString().Contains("chris@hydraulicsnetwork.com.au")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- chris@hydraulicsnetwork.com.au should be mentioned for MELBOURNE PORT in consignee field of HYDRAULICS NETWORK PTY LTD. \r\n";
        //            }

        //            ///USCI :91220101593387465F SHOULD BE THERE FOR BOSCH AUTOMOTIVE COMPONENTS (CHANGCHUN) CO IN CONSIGNEE FIELD FOR DALIAN
        //            /// 
        //            if ((dr["POD"].ToString().Contains("DALIAN")) && (dr["Consignee"].ToString().ToUpper().Contains("BOSCH AUTOMOTIVE COMPONENTS (CHANGCHUN) CO")) && (!dr["ConsigneeAddress"].ToString().Contains("91220101593387465F")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- USCI +91220101593387465F should be mentioned for DALIAN PORT in consignee field of BOSCH AUTOMOTIVE COMPONENTS (CHANGCHUN) CO. \r\n";
        //            }

        //            ///Contact person: Yingye SUO SHOULD BE THERE FOR BOSCH AUTOMOTIVE COMPONENTS (CHANGCHUN) CO IN CONSIGNEE FIELD FOR DALIAN
        //            /// 
        //            if ((dr["POD"].ToString().Contains("DALIAN")) && (dr["Consignee"].ToString().ToUpper().Contains("BOSCH AUTOMOTIVE COMPONENTS (CHANGCHUN) CO")) && (!dr["ConsigneeAddress"].ToString().Contains("Yingye SUO")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Contact person: Yingye SUO should be mentioned for DALIAN PORT in consignee field of BOSCH AUTOMOTIVE COMPONENTS (CHANGCHUN) CO. \r\n";
        //            }

        //            ///Telephone  # : 86 431 8195-0807 SHOULD BE THERE FOR BOSCH AUTOMOTIVE COMPONENTS (CHANGCHUN) CO IN CONSIGNEE FIELD FOR DALIAN
        //            /// 
        //            if ((dr["POD"].ToString().Contains("DALIAN")) && (dr["Consignee"].ToString().ToUpper().Contains("BOSCH AUTOMOTIVE COMPONENTS (CHANGCHUN) CO")) && (!dr["ConsigneeAddress"].ToString().Contains("86 431 8195-0807")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Telephone Number: +86 431 8195-0807 should be mentioned for DALIAN PORT in consignee field of BOSCH AUTOMOTIVE COMPONENTS (CHANGCHUN) CO. \r\n";
        //            }

        //            ///Added ON BHARAT PATIL REQUEST ON Tuesday, September 11, 2018 5:11 PM
        //            ///for Brazilian destination (Santos/Rio Grande/Rio de Janeiro/Manaus) we have to show in Body bl field Ocean Freight and EBS word should be mention
        //            if (dr["POD"].ToString().Contains("SANTOS") || dr["POD"].ToString().Trim().ToUpper().Contains("RIO GRANDE") || dr["POD"].ToString().Trim().ToUpper().Contains("RIO DE JANEIRO") || dr["POD"].ToString().Trim().ToUpper().Contains("MANAUS"))
        //            {
        //                if (!dr["Consignee"].ToString().ToUpper().Trim().Contains("DHL") && !dr["Shipper"].ToString().ToUpper().Trim().Contains("DHL"))
        //                {
        //                    int pos = p.searchdt(pdfsearchdt, "OCEAN FREIGHT");
        //                    if (pos == -1)
        //                        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- for Brazilian destination (Santos/Rio Grande/Rio de Janeiro/Manaus), OCEAN FREIGHT and EBS word should be mention. \r\n";

        //                    if (dr["Freight Type"].ToString().ToUpper().Contains("PREPAID"))
        //                    {
        //                        pos = p.searchdt(pdfsearchdt, "EBS");
        //                        if (pos == -1)
        //                            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- for Brazilian destination (Santos/Rio Grande/Rio de Janeiro/Manaus), EBS word should be mention. \r\n";
        //                    }
        //                }
        //            }

        //            ///Added ON BHARAT PATIL REQUEST ON Tuesday, September 11, 2018 5:11 PM
        //            ///Clause should be in Body bl field as "STAMP DUTY ON DELIVERY ORDERS ISSUED IN INDIA PAYABLE BY CARGO INTEREST/CONSIGNEE" for the  Nhava sheva & New Delhi ports
        //            if (dr["POD"].ToString().Contains("NHAVA SHEVA") || dr["POD"].ToString().Contains("NEW DELHI"))
        //            {
        //                int pos = p.searchdt(pdfsearchdt, "STAMP DUTY ON DELIVERY ORDERS ISSUED");
        //                if (pos == -1)
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Clause should be in Body bl field as 'STAMP DUTY ON DELIVERY ORDERS ISSUED IN INDIA PAYABLE BY CARGO INTEREST/ CONSIGNEE' for the  Nhava sheva & New Delhi ports \r\n";
        //            }
        //        }

        //        ///uPDATE ON BHARAT PATIL REQUEST ON Tuesday, September 11, 2018 5:11 PM
        //        if (dr["Marks Nos"].ToString() == "")
        //        {
        //            if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //            {
        //                if (dr["POD"].ToString().Trim().ToUpper().Trim().ToUpper().Contains("CASABLANCA") || dr["POD"].ToString().Trim().ToUpper().Trim().ToUpper().Contains("ALGERI") || dr["POD"].ToString().Trim().ToUpper().Contains("BANGKOK") || dr["POD"].ToString().Trim().ToUpper().Contains("DURBAN"))
        //                {

        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- MARKS AND NUMBERS CAN NOT BE BLANK FOR Italy POD's (CASABLANCA, ALGERI, BANGKOK,DURBAN). \r\n";
        //                }
        //            }
        //            else if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MRS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LEH" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LYS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "PAR")
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- MARKS AND NUMBERS CAN NOT BE BLANK FOR FRANCE. \r\n";
        //            }
        //        }


        //        ///Added  by Rahul Waghchaure on  07 Dec 2019
        //        ///
        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MRS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LEH" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LYS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "PAR")
        //        {
        //            if (countryname == "PAKISTAN")
        //            {
        //                if (dr["Consignee"].ToString().ToUpper().Trim().Contains("AFGHANISTAN") || dr["ConsigneeAddress"].ToString().ToUpper().Trim().Contains("AFGHANISTAN") || dr["Notify"].ToString().ToUpper().Trim().Contains("AFGHANISTAN") || dr["NotifyAddress"].ToString().ToUpper().Trim().Contains("AFGHANISTAN"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + " CNEE or NOTIFY FEILD CAN NOT BE IN AFGHANISTAN \r\n";
        //                }
        //            }
        //        }

        //        // Based on excel sheet provided by Nilesh.
        //        if (dr["Freight Type"].ToString() != "FREIGHT PREPAID" && dr["Freight Type"].ToString() != "FREIGHT COLLECT")
        //        {
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- Missed Freight Term Clause \r\n";
        //        }

        //        if (dr["Reference No."].ToString() == "" || dr["Reference No."].ToString() == "Missing Reference No")
        //        {
        //            if (dr["B L No."].ToString().Trim().Substring(0, 3) == "SIN"
        //                && (dr["Shipper"].ToString().Contains("PANALPINA WORLD TRANSPORT")
        //                    || dr["Shipper"].ToString().Contains("KUEHNE + NAGEL")
        //                    || dr["Shipper"].ToString().Contains("DHL GLOBAL FORWARDING")
        //                    || dr["Shipper"].ToString().Contains("SAVINO")
        //                    || dr["Shipper"].ToString().Contains("TSL")
        //                    || dr["Shipper"].ToString().Contains("DAMCO LOGISTICS")
        //                    || dr["Shipper"].ToString().Contains("JF HILLEBRAND")
        //                    || dr["Shipper"].ToString().ToUpper().Contains("GEODIS WILSON")
        //                    || dr["Shipper"].ToString().ToUpper().Contains("EXPEDITORS")
        //                    || dr["Shipper"].ToString().ToUpper().Contains("BDP")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General--Reference No. is Missing\r\n";
        //            }

        //            if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General--Reference No. is Missing\r\n";
        //            }

        //        }

        //        ///Removed as per confirmation received from - Bharat Patil on Thu 5/30/2019 4:34 PM
        //        ///
        //        //if (dr["POD"].ToString().Trim().ToUpper().Contains("MONTEVIDEO"))
        //        //{   
        //        //    if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //        //    {
        //        //        if (p.searchdt(pdfsearchdt, "CONSOLIDATED CARGO") == -1)
        //        //        {
        //        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- CONSOLIDATED CARGO \r\n";
        //        //        }

        //        //        if (p.searchdt(pdfsearchdt, "CARGA CONSOLIDADA") == -1)
        //        //        {
        //        //            {
        //        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- CARGA CONSOLIDADA \r\n";
        //        //            }
        //        //        }
        //        //    }
        //        //}



        //        ///Corrected  by Rahul Waghchaure on  07 Dec 2019
        //        ///PREVIOUSLY IT WAS JUST FOR MIL AND FOR POD - RIO GRAND, RIO DE JANEIRIO, SANTOS
        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL" || dr["B L No."].ToString().Trim().Substring(0, 3) == "ANR")
        //        {

        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("RIO GRANDE")
        //             || dr["POD"].ToString().Trim().ToUpper().Contains("RIO DE JANEIRO")
        //             || dr["POD"].ToString().Trim().ToUpper().Contains("SANTOS")
        //             || dr["POD"].ToString().Trim().ToUpper().Contains("ITAJAI")
        //             || dr["POD"].ToString().Trim().ToUpper().Contains("PARANAGUA")
        //           )
        //            {
        //                ///OLD Clause
        //                ///
        //                //if (p.searchdt(pdfsearchdt, "SHOW KIND OF PACKAGES (PLASTIC OR WOODEN PALLETS)") == -1)
        //                //{
        //                //    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- SHOW KIND OF PACKAGES (PLASTIC OR WOODEN PALLETS) ***\r\n";
        //                //}
        //                if (dr["Description"].ToString().ToUpper().Contains("WOODEN PALLET"))
        //                {
        //                    if (p.searchdt(pdfsearchdt, "WOODEN PACKAGE") == -1 && p.searchdt(pdfsearchdt, "TREATED") == -1)
        //                    {
        //                        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- WOODEN PACKAGES: TREATED CLAUSE IS MISSING\r\n";
        //                    }
        //                }
        //                else if (dr["Description"].ToString().ToUpper().Contains("PLASTIC PALLET") || dr["Description"].ToString().ToUpper().Contains("CARTONS") || dr["Description"].ToString().ToUpper().Contains("BOXES") || dr["Description"].ToString().ToUpper().Contains("BUDLE") || dr["Description"].ToString().ToUpper().Contains("DRUMS"))
        //                {
        //                    if (p.searchdt(pdfsearchdt, "WOODEN PACKAGE: NOT APPLICABLE") == -1)
        //                    {
        //                        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- WOODEN PACKAGE: NOT APPLICABLE\r\n";
        //                    }
        //                }
        //                else if (dr["Description"].ToString().ToUpper().Contains("PLYWOOD"))
        //                {
        //                    if (p.searchdt(pdfsearchdt, "WOODEN PACKAGE: PROCESSED WOOD") == -1)
        //                    {
        //                        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- WOODEN PACKAGE: PROCESSED WOOD\r\n";
        //                    }
        //                }


        //            }


        //        }


        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //        {
        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("RIO GRANDE")
        //              || dr["POD"].ToString().Trim().ToUpper().Contains("RIO DE JANEIRO")
        //              || dr["POD"].ToString().Trim().ToUpper().Contains("CHILE")
        //              || dr["POD"].ToString().Trim().ToUpper().Contains("PERU")
        //              || dr["POD"].ToString().Trim().ToUpper().Contains("ECUADOR")
        //              || dr["POD"].ToString().Trim().ToUpper().Contains("CARTAGENA")
        //              //|| dr["POD"].ToString().Trim().ToUpper().Contains("MIAMI")
        //              || dr["POD"].ToString().Trim().ToUpper().Contains("MONTEVIDEO")
        //              || dr["POD"].ToString().Contains("BUENOS AIRES")
        //              || dr["POD"].ToString().Contains("SANTOS")
        //              || dr["POD"].ToString().Contains("GUATEMALA")
        //              || dr["POD"].ToString().Contains("PARANAGUA")
        //                )
        //            {

        //                if (p.searchdt(pdfsearchdt, "ALL LOCAL DESTINATION CHARGES") == -1)
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- ALL LOCAL DESTINATION CHARGES ARE ALWAYS FOR ACCOUNT AND RISK OF CONSIGNEE \r\n";
        //                }

        //            }



        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("RIO GRANDE")
        //              || dr["POD"].ToString().Trim().ToUpper().Contains("RIO DE JANEIRO")
        //              || dr["POD"].ToString().Trim().ToUpper().Contains("ECUADOR")
        //              || dr["POD"].ToString().Trim().ToUpper().Contains("SANTOS")
        //            )
        //            {
        //                //if (p.searchdt(newSearchDt, "OCEAN FREIGHT") == 0)
        //                if (p.searchdt(pdfsearchdt, "OCEAN FREIGHT") == -1)
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- OCEAN FREIGHT \r\n";
        //                }

        //            }




        //            ///After confimration from bharat patil on 17-APR-2019 this clause was removed.
        //            ///
        //            //if (dr["POD"].ToString().Trim().ToUpper().Contains("RIO GRANDE")
        //            //  || dr["POD"].ToString().Trim().ToUpper().Contains("RIO DE JANEIRO")
        //            //  || dr["POD"].ToString().Trim().ToUpper().Contains("CHILE")
        //            //  || dr["POD"].ToString().Trim().ToUpper().Contains("CARTAGENA")
        //            //  || dr["POD"].ToString().Trim().ToUpper().Contains("MONTEVIDEO")
        //            //  || dr["POD"].ToString().Trim().ToUpper().Contains("BUENOS AIRES")
        //            //  || dr["POD"].ToString().Trim().ToUpper().Contains("SANTOS")
        //            //  || dr["POD"].ToString().Trim().ToUpper().Contains("ABIDJAN")
        //            //   )

        //            //{
        //            //    if (dr["BL Type"].ToString().Contains("EXPRESS"))
        //            //    {
        //            //        if (p.searchdt(pdfsearchdt, "ALL LOCAL DESTINATION CHARGES") == -1)
        //            //        {
        //            //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- ALL LOCAL DESTINATION CHARGES ARE ALWAYS FOR ACCOUNT AND RISK OF CONSIGNEE \r\n";
        //            //        }
        //            //    }

        //            //}

        //        }

        //        if (countryname == "US")
        //        {
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("EXPEDITORS") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER SCAC CODE EXDO HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE EXDO ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("CEVA") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER SCAC CODE PYRD HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE PYRD ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("AGILITY") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER SCAC CODE SQST HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE SQST ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("TRANSMEC") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER  SCAC CODE TSQD HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSQD ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("SDV") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER  SCAC CODE TSVC HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSVC ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("BOLLORE") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER  SCAC CODE TSVC HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSVC ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("TUVIA") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER  SCAC CODE IMAV HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE IMAV ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("DELTA") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER  SCAC CODE XOML HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE XOWL ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("CARGO COMPASS") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER  SCAC CODE CBLA HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE CBLA ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("Kuhne Nagal") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER  SCAC CODE BANQ HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE BANQ ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("SCHENKER") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER SCAC CODE SHKK HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE SHKK ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("DSV") && p.searchdt(newSearchDt, "SHIPMENT FILER UNDER SCAC CODE DSVF HBL NUMBER") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE DSV ACE "; }

        //            //if (dr["Consignee"].ToString().ToUpper().Contains("EXPEDITORS") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE EXDO ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("CEVA") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE PYRD ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("AGILITY") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE SQST ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("TRANSMEC") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER  SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSQD ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("SDV") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSVC ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("BOLLORE") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSVC ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("TUVIA") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE IMAV ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("DELTA") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE XOWL ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("CARGO COMPASS") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE CBLA ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("Kuhne Nagal") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE BANQ ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("SCHENKER") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE SHKK ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("DSV") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC CODE") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE DSV ACE "; }


        //            ///Removed as per confirmation of Bharat Patil on 5 DEC 2019 by Rahul Waghchaure
        //            ///
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("EXPEDITORS") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE EXDO ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("CEVA") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE PYRD ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("AGILITY") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE SQST ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("TRANSMEC") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER  SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSQD ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("SDV") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSVC ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("BOLLORE") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSVC ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("TUVIA") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE IMAV ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("DELTA") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE XOWL ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("CARGO COMPASS") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE CBLA ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("Kuhne Nagal") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE BANQ ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("SCHENKER") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE SHKK ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("DSV") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER SCAC CODE") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE DSV ACE "; }


        //            if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //            {
        //                if (p.searchdt(pdfsearchdt, "FMC CONTRACT NBR 002") == -1)
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- FMC CONTRACT NBR 002 \r\n";
        //                }

        //                //if (dr["Consignee"].ToString().ToUpper().Contains("EXPEDITORS") || dr["Consignee"].ToString().ToUpper().Contains("CEVA") || dr["Consignee"].ToString().ToUpper().Contains("AGILITY") || dr["Consignee"].ToString().ToUpper().Contains("TRANSMEC") || dr["Consignee"].ToString().ToUpper().Contains("SDV") || dr["Consignee"].ToString().ToUpper().Contains("BOLLORE") || dr["Consignee"].ToString().ToUpper().Contains("TUVIA") || dr["Consignee"].ToString().ToUpper().Contains("DELTA") || dr["Consignee"].ToString().ToUpper().Contains("CARGO COMPASS") || dr["Consignee"].ToString().ToUpper().Contains("Kuhne") || dr["Consignee"].ToString().ToUpper().Contains("SCHENKER") || dr["Consignee"].ToString().ToUpper().Contains("DSV"))
        //                //{
        //                //    if (!dr["Description"].ToString().Contains(dr["B L No."].ToString()))
        //                //    {
        //                //        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- ALL LOCAL DESTINATION CHARGES ARE ALWAYS FOR ACCOUNT AND RISK OF CONSIGNEE \r\n";
        //                //    }
        //                //}

        //                //if (dr["POD"].ToString().Trim().ToUpper().Contains("CHICAGO") || dr["POD"].ToString().Trim().ToUpper().Contains("HOUSTON") || dr["POD"].ToString().Trim().ToUpper().Contains("MIAMI") || dr["POD"].ToString().Trim().ToUpper().Contains("NEW YORK") || dr["POD"].ToString().Trim().ToUpper().Contains("CHARLESTON") || dr["POD"].ToString().Trim().ToUpper().Contains("LOS ANGELES"))
        //                //{
        //                if (dr["PLD"].ToString().ToUpper().Contains("DAP"))
        //                {
        //                    if (p.searchdt(pdfsearchdt, "ALL LOCAL CHARGES PREPAID") == -1)
        //                    {
        //                        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- ALL LOCAL CHARGES PREPAID \r\n";
        //                    }
        //                }
        //                else
        //                {
        //                    if ((p.searchdt(pdfsearchdt, "THC + STRIPPING") == -1) && (p.searchdt(pdfsearchdt, "THC AND STRIPPING") == -1))
        //                    {
        //                        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- THC + STRIPPING COLLECT should be in body bl field\r\n";
        //                    }
        //                }
        //                //}
        //            }
        //        }
        //        else if (countryname == "CANADA")
        //        {
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("DHL") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE EXDO ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("AGILITY") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE SQST ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("TRANSMEC") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSQD ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("UBV") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSVC ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("Kuhne Nagal") && p.searchdt(newSearchDt, "SHIPMENT FILED UNDER SCAC") != 0) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE BANQ ACE "; }


        //            /// AS per confirmation removed on 18 Dec 2019 from Bharat patil by Rahul wAghchaure
        //            /// 

        //            //if (dr["Consignee"].ToString().ToUpper().Contains("DHL") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE EXDO ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("AGILITY") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE SQST ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("TRANSMEC") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSQD ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("UBV") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE TSVC ACE "; }
        //            //if (dr["Consignee"].ToString().ToUpper().Contains("Kuhne Nagal") && p.searchdt(pdfsearchdt, "SHIPMENT FILED UNDER") == -1) { dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --FILER SCAC CODE BANQ ACE "; }



        //            ///Removed on Thursday, October 11, 2018 7:57 PM from Bharat Patil
        //            ///
        //            //if (p.searchdt(pdfsearchdt, "FMC CONTRACT NBR 002") == -1)
        //            //{
        //            //    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- FMC CONTRACT NBR 002 \r\n";
        //            //}

        //            //if (dr["POD"].ToString().Trim().ToUpper().Contains("CHICAGO") || dr["POD"].ToString().Trim().ToUpper().Contains("HOUSTON") || dr["POD"].ToString().Trim().ToUpper().Contains("MIAMI") || dr["POD"].ToString().Trim().ToUpper().Contains("NEW YORK") || dr["POD"].ToString().Trim().ToUpper().Contains("CHARLESTON") || dr["POD"].ToString().Trim().ToUpper().Contains("LOS ANGELES"))
        //            //{
        //            //    if (p.searchdt(pdfsearchdt, "THC COLLECT") == -1)
        //            //    {
        //            //        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- THC Collect should be THC Prepaid\r\n";
        //            //    }
        //            //}
        //        }
        //        else if (countryname == "INDIA")
        //        {
        //            if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //            {
        //                if (!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("PAN")
        //                     && !dr["Consignee"].ToString().Trim().ToUpper().Contains("PAN")
        //                     && !dr["Notify"].ToString().Trim().ToUpper().Contains("PAN")
        //                     && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("PAN"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  PAN # is mandatory for INDIA Shipment in CNEE/Notify field\r\n";
        //                }

        //                if (!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("GST")
        //                    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("GST")
        //                    && !dr["Notify"].ToString().Trim().ToUpper().Contains("GST")
        //                    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("GST"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  GST # is mandatory for INDIA Shipment in CNEE/Nofify field\r\n";
        //                }

        //                if (!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("IEC")
        //                 && !dr["Consignee"].ToString().Trim().ToUpper().Contains("IEC")
        //                 && !dr["Notify"].ToString().Trim().ToUpper().Contains("IEC")
        //                 && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("IEC")
        //                 && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("I.E.C")
        //                 && !dr["Consignee"].ToString().Trim().ToUpper().Contains("I.E.C")
        //                 && !dr["Notify"].ToString().Trim().ToUpper().Contains("I.E.C")
        //                 && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("I.E.C")
        //                 )
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  IEC CODE # is mandatory for INDIA Shipment  in CNEE/Nofify field\r\n";
        //                }

        //            }
        //            else
        //            {
        //                if (!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("PAN")
        //                 && !dr["Consignee"].ToString().Trim().ToUpper().Contains("PAN")
        //                 && !dr["Notify"].ToString().Trim().ToUpper().Contains("PAN")
        //                 && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("PAN")
        //                 && !dr["Marks Nos"].ToString().Trim().ToUpper().Contains("PAN")
        //                 && !dr["Description"].ToString().Trim().ToUpper().Contains("PAN"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  PAN # is mandatory for INDIA Shipment\r\n";
        //                }

        //                if (!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("GST")
        //               && !dr["Consignee"].ToString().Trim().ToUpper().Contains("GST")
        //               && !dr["Notify"].ToString().Trim().ToUpper().Contains("GST")
        //               && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("GST")
        //               && !dr["Marks Nos"].ToString().Trim().ToUpper().Contains("GST")
        //               && !dr["Description"].ToString().Trim().ToUpper().Contains("GST"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  GST # is mandatory for INDIA Shipment\r\n";
        //                }

        //                if (!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("IEC")
        //                     && !dr["Consignee"].ToString().Trim().ToUpper().Contains("IEC")
        //                     && !dr["Notify"].ToString().Trim().ToUpper().Contains("IEC")
        //                     && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("IEC")
        //                     && !dr["Marks Nos"].ToString().Trim().ToUpper().Contains("IEC")
        //                     && !dr["Description"].ToString().Trim().ToUpper().Contains("IEC")
        //                     && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("I.E.C")
        //                     && !dr["Consignee"].ToString().Trim().ToUpper().Contains("I.E.C")
        //                     && !dr["Notify"].ToString().Trim().ToUpper().Contains("I.E.C")
        //                     && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("I.E.C")
        //                     && !dr["Marks Nos"].ToString().Trim().ToUpper().Contains("I.E.C")
        //                     && !dr["Description"].ToString().Trim().ToUpper().Contains("I.E.C")
        //                     )
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  IEC CODE # is mandatory for INDIA Shipment in \r\n";
        //                }
        //            }



        //            //if (dr["Description"].ToString().ToUpper().Contains("HS") && dr["Description"].ToString().ToUpper().Contains("CODE"))
        //            //{
        //            //    if (dr["HS CODE"].ToString().Replace(".", "").Replace(" ", "").Length != 8)
        //            //    {
        //            //        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "INDIA Shipment -- HS Code error\r\n";
        //            //    }
        //            //}
        //            //else
        //            //{
        //            //    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "INDIA Shipment -- HS Code Required\r\n";
        //            //}


        //            if (checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString()))
        //            {
        //                string ss = dr["Description"].ToString().Replace(".", "").Replace(" ", "");

        //                int index = ss.IndexOf("CODE:");

        //                if (index != -1)
        //                {
        //                    //DO YOUR LOGIC
        //                    string errorCode = ss.Substring(index + 5);
        //                    string str = errorCode.Substring(0, 9);
        //                    if (str.Length <= 8)
        //                    {
        //                        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "INDIA Shipment -- HS Code error\r\n";
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "INDIA Shipment -- HS Code Required\r\n";
        //            }
        //        }

        //        ///
        //        ///Added  by Rahul Waghchaure on  07 Dec 2019
        //        else if (countryname == "CHINA")
        //        {
        //            if (!dr["Consignee"].ToString().ToUpper().Trim().Contains("USCI") && !dr["ConsigneeAddress"].ToString().ToUpper().Trim().Contains("USCI") && !dr["Notify"].ToString().ToUpper().Trim().Contains("USCI") && !dr["NotifyAddress"].ToString().ToUpper().Trim().Contains("USCI"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CHINA SHIPMENT -- USCI Required IN CONSIGNEE OR NOTIFY\r\n";
        //            }
        //        }


        //        if (dr["POD"].ToString().ToUpper().Contains("DALIAN")
        //            || dr["POD"].ToString().ToUpper().Contains("QINGDAO")
        //            || dr["POD"].ToString().ToUpper().Contains("SHANGHAI")
        //            || dr["POD"].ToString().ToUpper().Contains("XINGANG")
        //            || dr["POD"].ToString().ToUpper().Contains("ASHDOD")
        //            || dr["POD"].ToString().ToUpper().Contains("HAIFA")
        //            || dr["POD"].ToString().ToUpper().Contains("HUANGPU")
        //            || dr["POD"].ToString().ToUpper().Contains("OLD PORT VIA HONG KONG"))
        //        {
        //            //if (!dr["Shipper"].ToString().ToUpper().Trim().Contains("VAT")
        //            //   && !dr["ShipperAddress"].ToString().ToUpper().Trim().Contains("VAT")
        //            //   && !dr["Shipper"].ToString().ToUpper().Trim().Contains("REG")
        //            //   && !dr["ShipperAddress"].ToString().ToUpper().Trim().Contains("REG")
        //            //   && !dr["Shipper"].ToString().ToUpper().Trim().Contains("BTW")
        //            //   && !dr["ShipperAddress"].ToString().ToUpper().Trim().Contains("BTW")
        //            //   && !dr["Shipper"].ToString().ToUpper().Trim().Contains("USCI")
        //            //   && !dr["ShipperAddress"].ToString().ToUpper().Trim().Contains("USCI")
        //            //   && !dr["Shipper"].ToString().ToUpper().Trim().Contains("TVA")
        //            //   && !dr["ShipperAddress"].ToString().ToUpper().Trim().Contains("TVA")
        //            //   )                    
        //            if (!checkTAXCODE(dr["Shipper"].ToString().ToUpper(), dr["ShipperAddress"].ToString().ToUpper()) && !checkTAXCODE(dr["Marks Nos"].ToString().ToUpper(), dr["Description"].ToString().ToUpper()))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CHINA SHIPMENT --  VAT/REG/BTW/USCI/TVA Required IN SHIPPER or BODY BL\r\n";
        //            }

        //        }

        //        ///Condition updated as per France port as POL on .
        //        ///
        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "PAR" || dr["B L No."].ToString().Trim().Substring(0, 3) == "MRS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LEH" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LYS")
        //        {

        //            if (!dr["FreightBill"].ToString().Trim().Contains("SHIPPED ON BOARD")
        //                && !dr["Description"].ToString().Trim().Contains("SHIPPED ON BOARD"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- SHIPPED ON BOARD # is mandatory Shipment\r\n";

        //            }
        //            //Net weight PORT KELANG,KARACHI OLD PORT,HOCHIMINH only for france
        //            ///Corrected  by Rahul Waghchaure on  07 Dec 2019
        //            if ((!dr["Description"].ToString().Trim().ToUpper().Contains("NET WEIGHT")
        //                && (!dr["Description"].ToString().Trim().ToUpper().Contains("NET")
        //                && !dr["Description"].ToString().Trim().ToUpper().Contains("WEIGHT")))
        //                && (dr["POD"].ToString().ToUpper().Contains("PORT KELANG")
        //                    || dr["POD"].ToString().ToUpper().Contains("KARACHI OLD PORT")
        //                    || dr["POD"].ToString().ToUpper().Contains("HOCHIMINH")))

        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  Net weight # is not captured \r\n";
        //            }

        //            if (!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("AFGHANISTAN")
        //                && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("AFGHANISTAN")
        //                && (dr["POD"].ToString().ToUpper().Contains("ISLAMABAD")
        //                || dr["POD"].ToString().ToUpper().Contains("KARACHI PICT")
        //                || dr["POD"].ToString().ToUpper().Contains("LAHORE")
        //                || dr["POD"].ToString().ToUpper().Contains("PORT QASIM")
        //                || dr["POD"].ToString().ToUpper().Contains("RAWALPINDI")
        //                || dr["POD"].ToString().ToUpper().Contains("SIALKOT")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  AFGHANISTAN # Capture in Consignee \r\n";
        //            }

        //            if (!dr["Description"].ToString().Trim().ToUpper().Contains("FORM M NUMBER MANDATORY") && dr["POD"].ToString().ToUpper().Contains("Lagos"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  Does not Capture in Description # FORM M NUMBER MANDATORY \r\n";
        //            }

        //            if (!dr["Description"].ToString().Trim().ToUpper().Contains("FORM M NUMBER AND BA NUMBER MANDATORY") && dr["POD"].ToString().ToUpper().Contains("Port Harcourt"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  Does not Capture in Description # FORM M NUMBER AND BA NUMBER MANDATORY \r\n";
        //            }

        //            ///Corrected  by Rahul Waghchaure on  07 Dec 2019
        //            if ((dr["Freight Type"].ToString().ToUpper().Trim().Contains("COLLECT"))
        //                && (dr["POD"].ToString().Trim().ToUpper().Contains("DAKAR")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("TEMA")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("FREETOWN")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("DONGYANG")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("HUANGPU")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("NEW PORT")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("JISI")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("DUN HUA VIA DALIAN")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("FA KU VIA DALIAN")
        //                    ))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  Frieght Collect not Allowed \r\n";
        //            }

        //            ///Added by Rahul Waghchaure on  07 Dec 2019
        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("HONG KONG") && dr["Description"].ToString().ToUpper().Contains("WINE") && !dr["Description"].ToString().ToUpper().Contains("%") && !dr["Marks Nos"].ToString().ToUpper().Contains("%") && !dr["FreightBill"].ToString().ToUpper().Contains("%"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General --% # Description field should not contain. \r\n";
        //            }

        //            ///Added by Rahul Waghchaure on  07 Dec 2019
        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("HONG KONG") && !checkHSCODE(dr["Description"].ToString().ToUpper(), dr["Marks Nos"].ToString().ToUpper()))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General --HS Code Missing for HONG KONG Port. \r\n";
        //            }

        //            ///Added by Rahul Waghchaure on  07 Dec 2019
        //            ///Updated for PLD Condition if PLD Is blank OR is same as POD then only HS Code Required condition will be checked. Mail from Bharat Patil on Tue 12/17/2019 3:56 PM
        //            if ((dr["POD"].ToString().Trim().ToUpper().Contains("SINGAPORE")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("SHANGHAI")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("BEIRUT")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("DURBAN")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("DAKAR"))
        //                    && (dr["PLD"].ToString().Trim().ToUpper() == "" || (dr["POD"].ToString().Trim().ToUpper() == dr["PLD"].ToString().Trim().ToUpper()))
        //                && !checkHSCODE(dr["Description"].ToString().ToUpper(), dr["Marks Nos"].ToString().ToUpper()))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General --% HS Code Missing for SINGAPORE, SHANGHAI, BEIRUT, DURBAN, DAKAR. \r\n";
        //            }

        //        }

        //        if (dr["POD"].ToString().ToUpper().Contains("ANTWERP"))
        //        {
        //            //Consignee or Notify or in Goods description CNPJ no. mandatory  Only for France & Antwerp
        //            if (!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                && !dr["Consignee"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                && !dr["Notify"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                && !dr["Description"].ToString().Trim().ToUpper().Contains("CNPJ"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  CNPJ NO # is mandatory for ANTWERP Shipment\r\n";
        //            }
        //        }


        //        if (dr["POD"].ToString().Trim().ToUpper().Contains("CHILLE"))
        //        {
        //            if (dr["PLD"].ToString().ToUpper().Contains(dr["SANTACRUZ"].ToString()) || dr["PLD"].ToString().ToUpper().Contains(dr["LA PAZ"].ToString()))
        //            {
        //                //if (p.searchdt(newSearchDt, "CARGO IN TRANSIT TO") != 0)
        //                if (p.searchdt(pdfsearchdt, "CARGO IN TRANSIT TO") == -1)
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  CARGO IN TRANSIT TO ________(Name of the Location)\r\n";
        //                }
        //            }
        //        }


        //        if (dr["POD"].ToString().Trim().ToUpper().Contains("ALEXANDRIA"))
        //        {
        //            //if (p.searchdt(newSearchDt, "FINAL CFS ECUWORLDWIDE EGYPT LTD BONDED WAREHOUSE EL KABARY - ALEXANDRIA") != 0)
        //            if ((p.searchdt(pdfsearchdt, "FINAL") == -1) && (p.searchdt(pdfsearchdt, "EGYPT") == -1) && (p.searchdt(pdfsearchdt, "WAREHOUSE") == -1))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  FINAL CFS ECUWORLDWIDE EGYPT LTD BONDED WAREHOUSE EL KABARY - ALEXANDRIA \r\n";
        //            }
        //        }

        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //        {
        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("DELHI") || dr["POD"].ToString().Trim().ToUpper().Contains("NAVA SHEVA") || dr["POD"].ToString().Trim().ToUpper().Contains("KARACHI"))
        //            {
        //                if (p.searchdt(pdfsearchdt, "STAMP DUTY ON DELIVERY ORDERS ISSUED IN INDIA PAYABLE BY CARGO INTERES") == -1)
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- STAMP DUTY ON DELIVERY ORDERS ISSUED IN INDIA PAYABLE BY CARGO INTEREST/CNEE \r\n";
        //                }
        //            }
        //        }
        //        //if (p.searchdt(newSearchDt, "LCL/LCL") != 0)
        //        //{
        //        //    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() +  "CLAUSE -- LCL/LCL not allowed \r\n";
        //        //}
        //        ////End of instruction by Nilesh .


        //        // Based on Email provided by Nilesh.
        //        //Pallets, Skids are not allowed as a package type. for Mexico, USA, Canada Ports       

        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //        {
        //            if ((countryname == "US" || countryname == "CANADA" || countryname == "MEXICO") && dr["Description"].ToString().ToUpper().Contains("PALLET"))
        //            {
        //                //dr["Description"].Style.BackColor = System.Drawing.Color.Red;
        //                string tempDesc = dr["Description"].ToString();

        //                string[] lines = tempDesc.Split(new[] { "\r", "\n" }, StringSplitOptions.None);

        //                if ((lines[0].ToString().Contains("PALLET")) && !lines[0].ToString().ToUpper().Contains("ON"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "" + countryname + " Shipment -- Cannot use Pallet \r\n";
        //                }
        //            }
        //        }
        //        else if (dr["B L No."].ToString().Trim().Substring(0, 3) == "ANR" || dr["B L No."].ToString().Trim().Substring(0, 3) == "PAR" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LYS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "MRS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LEH")
        //        {
        //            if ((countryname == "US") && dr["Description"].ToString().ToUpper().Contains("PALLET"))
        //            {
        //                //dr["Description"].Style.BackColor = System.Drawing.Color.Red;
        //                string tempDesc = dr["Description"].ToString();

        //                string[] lines = tempDesc.Split(new[] { "\r", "\n" }, StringSplitOptions.None);

        //                if ((lines[0].ToString().Contains("PALLET")) && !lines[0].ToString().ToUpper().Contains("ON"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "" + countryname + " Shipment -- Cannot use Pallet \r\n";
        //                }
        //            }
        //        }

        //        if ((countryname == "US" || countryname == "CANADA")
        //            && checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString())
        //            && (dr["HS CODE"].ToString().Length > 10 && dr["HS CODE"].ToString().Length < 6))
        //        {
        //            // dr["HS Code"].Style.BackColor = System.Drawing.Color.Red;
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "US Shipment -- HS Code error length should be 6-10 digit\r\n";
        //        }
        //        else
        //        {
        //            // dr["HS Code"].Style.BackColor = System.Drawing.Color.White;
        //        }

        //        //	New exception – for Alger port express bl not allow in all region.
        //        ///Removed as confirmed on 18/12/2019 by Bharat patil
        //        //if (dr["POD"].ToString().ToUpper().Contains("ALGIERS") || dr["POD"].ToString().ToUpper().Contains("ALGERIE"))
        //        //{   
        //        //    if (dr["BL Type"].ToString() == "EXPRESS B/L")
        //        //    {
        //        //        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- BL Type Express should not allow\r\n";
        //        //    }
        //        //}


        //        if (dr["POD"].ToString().ToUpper().Contains("BUENOS AIRES"))
        //        {
        //            if (dr["BL Type"].ToString().ToUpper().Contains("EXPRESS"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- BL Type Express should not allow\r\n";
        //            }


        //            if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL" || dr["B L No."].ToString().Trim().Substring(0, 3) == "ANR")
        //            {
        //                if (p.searchdt(pdfsearchdt, "ALL LOCAL DESTINATION CHARGES") == -1)
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- ALL LOCAL DESTINATION CHAREGES CLAUSE SHOULD BE ON IN BL BODY\r\n";
        //                }

        //                if (p.searchdt(pdfsearchdt, "CONSOLIDATED CARGO") == -1)
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- CONSOLIDATED CARGO \r\n";
        //                }

        //            }
        //        }
        //        if (dr["POL"].ToString().Contains(dr["POD"].ToString()) || dr["POD"].ToString().Contains(dr["POL"].ToString()))
        //        {
        //            // dr["POL"].Style.BackColor = System.Drawing.Color.Red;
        //            //  dr["POD"].Style.BackColor = System.Drawing.Color.Red;
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- POD and POL cannot be same\r\n";
        //        }

        //        if (dr["PLR"].ToString().Contains(dr["POD"].ToString()) || dr["POD"].ToString().Contains(dr["PLR"].ToString()) && dr["PLR"].ToString() != "")
        //        {
        //            //    dr["PLR"].Style.BackColor = System.Drawing.Color.Red;
        //            //    dr["POD"].Style.BackColor = System.Drawing.Color.Red;
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- POD and PLR cannot be same\r\n";
        //        }
        //        else
        //        {
        //            // dr["POL"].Style.BackColor = System.Drawing.Color.White;
        //            //  dr["POD"].Style.BackColor = System.Drawing.Color.White;
        //        }

        //        ///Removed as per confirmation mail from bharat patil on Mon 1/6/2020 4:36 PM
        //        //if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MRS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LEH" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LYS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "PAR")
        //        //{
        //        //    if ((dr["POD"].ToString().ToUpper().Contains("ALEXANDRIA")
        //        //        || dr["POD"].ToString().ToUpper().Contains("ASHDOD")
        //        //        || dr["POD"].ToString().ToUpper().Contains("JAKARTA")
        //        //        || dr["POD"].ToString().ToUpper().Contains("DUBAI")
        //        //        || dr["POD"].ToString().ToUpper().Contains("BUSAN")
        //        //        || dr["POD"].ToString().ToUpper().Contains("CASABLANCA")
        //        //        || dr["POD"].ToString().ToUpper().Contains("PORT KELANG")
        //        //        || dr["POD"].ToString().ToUpper().Contains("TOKYO")
        //        //        || dr["POD"].ToString().ToUpper().Contains("KARACHI")
        //        //        || dr["POD"].ToString().ToUpper().Contains("HOCHIMINH")
        //        //        || dr["POD"].ToString().ToUpper().Contains("SANTO DOMINGO")
        //        //        || dr["POD"].ToString().ToUpper().Contains("BUENAVENTURA")
        //        //        || dr["POD"].ToString().ToUpper().Contains("MANZANILLO")
        //        //        || dr["POD"].ToString().ToUpper().Contains("PUERTO BARRIOS")
        //        //        || dr["POD"].ToString().ToUpper().Contains("CALLAO")
        //        //        || dr["POD"].ToString().ToUpper().Contains("SAN ANTONIO")
        //        //        || dr["POD"].ToString().ToUpper().Contains("MONTEVIDEO")
        //        //        || dr["POD"].ToString().ToUpper().Contains("SAN JUAN")
        //        //        || dr["POD"].ToString().ToUpper().Contains("ALGER")
        //        //        || dr["POD"].ToString().ToUpper().Contains("BEJAIA")
        //        //        || dr["POD"].ToString().ToUpper().Contains("BEIRUT")
        //        //        || dr["POD"].ToString().ToUpper().Contains("HAIFA")
        //        //        || dr["POD"].ToString().ToUpper().Contains("LIMASSOL")
        //        //        || dr["POD"].ToString().ToUpper().Contains("MALABO")
        //        //        || dr["POD"].ToString().ToUpper().Contains("ORAN")
        //        //        || dr["POD"].ToString().ToUpper().Contains("ISTANBUL")
        //        //        || dr["POD"].ToString().ToUpper().Contains("TRIPOLI")
        //        //        || dr["POD"].ToString().ToUpper().Contains("HAIPHONG")
        //        //        || (countryname == "MEXICO")
        //        //        || countryname == "US"
        //        //        || countryname == "JAPAN"
        //        //        || countryname == "AUSTRALIA"
        //        //        )
        //        //          && (!checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString())))
        //        //    {
        //        //        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "HS Code Missing For France Region\r\n";
        //        //    }
        //        //}

        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "MIL")
        //        {
        //            if ((dr["POD"].ToString().ToUpper().Contains("ALEXANDRIA")
        //                    || dr["POD"].ToString().ToUpper().Contains("ASHDOD")
        //                    || dr["POD"].ToString().ToUpper().Contains("JAKARTA")
        //                    || dr["POD"].ToString().ToUpper().Contains("DUBAI")
        //                    || dr["POD"].ToString().ToUpper().Contains("BUSAN")
        //                    || dr["POD"].ToString().ToUpper().Contains("CASABLANCA")
        //                    || dr["POD"].ToString().ToUpper().Contains("PORT KELANG")
        //                    || dr["POD"].ToString().ToUpper().Contains("TOKYO")
        //                    || dr["POD"].ToString().ToUpper().Contains("HOCHIMINH")
        //                    || dr["POD"].ToString().ToUpper().Contains("CALLAO")
        //                    || dr["POD"].ToString().ToUpper().Contains("MONTEVIDEO")
        //                    || dr["POD"].ToString().ToUpper().Contains("ALGER")
        //                    || dr["POD"].ToString().ToUpper().Contains("LIMASSOL")
        //                    || dr["POD"].ToString().ToUpper().Contains("HAIPHONG")
        //                    ///HS CODE not REQUIRED-If Shipper is BASF validation #51
        //                    ///
        //                    || (countryname == "MEXICO" && !dr["Shipper"].ToString().ToUpper().Contains("FERCAM"))
        //                    || countryname == "US"
        //                    || countryname == "JAPAN"
        //                    || countryname == "AUSTRALIA"
        //                )
        //                  && (!checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString())))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "HS Code Missing For ITALY Region\r\n";
        //            }

        //        }


        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "ANR")
        //        {
        //            if ((dr["POD"].ToString().ToUpper().Contains("ALEXANDRIA")
        //                    || dr["POD"].ToString().ToUpper().Contains("ASHDOD")
        //                    || dr["POD"].ToString().ToUpper().Contains("JAKARTA")
        //                    ///Removed Dubai port can you please remove exception in ANR region HS Code not mandatory as per mail on Fri 1/3/2020 9:57 PM from Bharat Patil
        //                    ///

        //                    //|| dr["POD"].ToString().ToUpper().Contains("DUBAI")
        //                    || dr["POD"].ToString().ToUpper().Contains("CASABLANCA")
        //                    || dr["POD"].ToString().ToUpper().Contains("PORT KELANG")
        //                    || dr["POD"].ToString().ToUpper().Contains("TOKYO")
        //                    || dr["POD"].ToString().ToUpper().Contains("KARACHI")
        //                    || dr["POD"].ToString().ToUpper().Contains("HOCHIMINH")
        //                    || dr["POD"].ToString().ToUpper().Contains("BUENOS AIRES")
        //                    || dr["POD"].ToString().ToUpper().Contains("BUENAVENTURA")
        //                    || dr["POD"].ToString().ToUpper().Contains("MANZANILLO")
        //                    || dr["POD"].ToString().ToUpper().Contains("CALLAO")
        //                    || dr["POD"].ToString().ToUpper().Contains("SAN ANTONIO")
        //                    || dr["POD"].ToString().ToUpper().Contains("MONTEVIDEO")
        //                    || dr["POD"].ToString().ToUpper().Contains("SAN JUAN")
        //                    || dr["POD"].ToString().ToUpper().Contains("ALGER")
        //                    || dr["POD"].ToString().ToUpper().Contains("BEJAIA")
        //                    || dr["POD"].ToString().ToUpper().Contains("BEIRUT")
        //                    || dr["POD"].ToString().ToUpper().Contains("LIMASSOL")
        //                    || dr["POD"].ToString().ToUpper().Contains("MALABO")
        //                    || dr["POD"].ToString().ToUpper().Contains("ORAN")
        //                    || dr["POD"].ToString().ToUpper().Contains("ISTANBUL")
        //                    || dr["POD"].ToString().ToUpper().Contains("TRIPOLI")
        //                    || dr["POD"].ToString().ToUpper().Contains("HAIPHONG")
        //                    || countryname == "MEXICO"
        //                    || countryname == "US"
        //                    || countryname == "JAPAN"
        //                    || countryname == "AUSTRALIA"
        //                )
        //                  && (!checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString())) && !dr["Description"].ToString().Contains("NCM"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "HS Code Missing For ANTWERP Region\r\n";
        //            }

        //            if ((dr["POD"].ToString().ToUpper().Contains("BAHRAIN")
        //                || dr["POD"].ToString().ToUpper().Contains("AQABA")
        //                || dr["POD"].ToString().ToUpper().Contains("AMMAN")
        //                || dr["POD"].ToString().ToUpper().Contains("SHUWAIKH")
        //                || dr["POD"].ToString().ToUpper().Contains("KUWAIT")
        //                || dr["POD"].ToString().ToUpper().Contains("SOHAR")
        //                || dr["POD"].ToString().ToUpper().Contains("DOHA")
        //                || dr["POD"].ToString().ToUpper().Contains("HAMAD")
        //                || dr["POD"].ToString().ToUpper().Contains("RIYADH")
        //                || dr["POD"].ToString().ToUpper().Contains("DAMMAM")
        //                || dr["POD"].ToString().ToUpper().Contains("JUBAIL")
        //                || dr["POD"].ToString().ToUpper().Contains("JEDDAH")
        //                ///Removed Dubai port can you please remove exception in ANR region HS Code not mandatory as per mail on Fri 1/3/2020 9:57 PM from Bharat Patil
        //                ///
        //                //|| dr["POD"].ToString().ToUpper().Contains("DUBAI")
        //                || dr["POD"].ToString().ToUpper().Contains("ABU DAHABI")
        //                || dr["POD"].ToString().ToUpper().Contains("JEBEL ALI")
        //                || dr["POD"].ToString().ToUpper().Contains("SHARJAH")
        //                || dr["POD"].ToString().ToUpper().Contains("ADEN")
        //                )
        //                && (!dr["Shipper"].ToString().ToUpper().Contains("BASF") && !dr["ShipperAddress"].ToString().ToUpper().Contains("BASF"))
        //                && (!checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString())))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "HS Code Missing For ANTWERP Region\r\n";
        //            }

        //        }


        //        ///Validation #48 added on 18 Dec 2019
        //        ///
        //        if (dr["POD"].ToString().ToUpper().Contains("ALGER") && (dr["B L No."].ToString().Trim().Substring(0, 3) == "LYS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "MRS"))
        //        {
        //            if (!checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString()))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "HS Code Missing for Alger POD for LYS and MRS Regions\r\n";
        //            }
        //        }
        //        //}
        //        ///Added  by Rahul Waghchaure on  07 Dec 2019
        //        ///
        //        if (dr["POD"].ToString().ToUpper().Contains("SAN ANTONIO") && !dr["BL Type"].ToString().ToUpper().Contains("ORIGINAL"))
        //        {
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- FOR ASUNCTION POD, BILL MUST BE ORIGINAL \r\n";
        //        }

        //        ///Singapore Validation
        //        ///
        //        if (dr["B L No."].ToString().Substring(0, 3) == "SIN")
        //        {
        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("KAOHSIUNG")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("KEELUNG")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("TAICHUNG")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("BANGKOK PAT")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("BANGKOK")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("LAD KRABANG")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("YOKOHAMA")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("TOKYO")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("SOUTHAMPTON")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("OSAKA")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("NEW YORK")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("NAGOYA")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("MOJI")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("LOS ANGELES")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("KOBE")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("FELIXSTOWE"))
        //            {
        //                if (dr["Marks Nos"].ToString().Trim().ToUpper().Contains("N/M") || dr["Marks Nos"].ToString().Trim() == "")
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- N/M is not allowed in Marks andn Nos.\r\n";
        //                }
        //            }

        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("SANTOS")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("RIO GRANDE")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("RIO DE JANERIO")
        //                    || dr["POD"].ToString().Trim().ToUpper().Contains("PARANAGUA"))
        //            {
        //                if (dr["Description"].ToString().Trim().ToUpper().Contains("PACKAGE"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- PACKAGE IS NOT ALLOWED IN GOODS DESCRIPTION.\r\n";
        //                }
        //            }

        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("NEW YORK")
        //                   || dr["POD"].ToString().Trim().ToUpper().Contains("LOS ANGELES"))
        //            {
        //                if (dr["Description"].ToString().Trim().ToUpper().Contains("PACKAGE")
        //                    || dr["Description"].ToString().Trim().ToUpper().Contains("SKIDS")
        //                    || dr["Description"].ToString().Trim().ToUpper().Contains("LIFTVAN")
        //                    || dr["Description"].ToString().Trim().ToUpper().Contains("BUNDLE"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- PALLETS, SKIDS, LIFTVAN, BUNDLE IS NOT ALLOWED IN GOODS DESCRIPTION.\r\n";
        //                }
        //            }


        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("MANZANILLO") && !checkTAXCODE(dr["ConsigneeAddress"].ToString().Trim().ToUpper(), dr["Consignee"].ToString().Trim().ToUpper()))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- TAX CODE IS MISSING.\r\n";
        //            }

        //            if ((dr["POD"].ToString().Trim().ToUpper().Contains("HAMBURG")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("OSAKA")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("TOKYO")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("NAGOYA")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("YOKOHAMA")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("KOBE")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("MOJI MANILA")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("DAVAO")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("CEBU")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("PORT KELANG")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("QINGDAO")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("BRISBANE")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("DARWIN")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("FREMANTLE")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("MELBOURNE")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("SYDNEY")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("NEW YORK")
        //                || dr["POD"].ToString().Trim().ToUpper().Contains("LOS ANGELES"))
        //                && Regex.Replace(dr["HS CODE"].ToString().Trim(), "[^0-9]", " ").Trim().Length != 6)
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- SIN REGION SHIPMENT SHOULD HAVE 6 DIGIT HS CODE.\r\n";
        //            }
        //        }

        //        if (dr["B L No."].ToString().Substring(0, 3) == "ANR")
        //        {
        //            ///CORRECTED ON 10 DEC 2019 BY RAHUL WAGHCAHRUE
        //            if ((dr["POD"].ToString().ToUpper().Contains("CAPE TOWN") || dr["POD"].ToString().ToUpper().Contains("DURBAN") || dr["POD"].ToString().ToUpper().Contains("PORT ELISABETH")) && dr["Shipper"].ToString().Trim().ToUpper().Contains("FRIENDSHIP"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- FRIENDSHIP - NEED TO CAPTURE :-  FRIENDSHIP / MST AS AGENTS FOR  IN SHIPPER 1ST LINE.\r\n";
        //            }

        //            ///Corrected  by Rahul Waghchaure on  07 Dec 2019
        //            ///
        //            if ((dr["Consignee"].ToString().Trim().ToUpper().Contains("TO ORDER") || dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("TO ORDER")) && (dr["POD"].ToString().ToUpper().Contains("MARIEL") || dr["POD"].ToString().ToUpper().Contains("PORT AU PRINCE")))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General --To order DOES NOT ALLOWED IN CONSIGNEE FIELD.\r\n";
        //            }


        //            if (!dr["Description"].ToString().Trim().Contains("SHIPPED ON BOARD") && !dr["FreightBill"].ToString().Trim().Contains("SHIPPED ON BOARD"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- SHIPPED ON BOARD # is mandatory Shipment\r\n";

        //            }

        //            if (dr["POL"].ToString().Trim().Contains("ANTWERP"))
        //            {
        //                if ((!dr["FreightBill"].ToString().Trim().Contains("LOCAL DESTINATION CHARGES AND") && !dr["FreightBill"].ToString().Trim().Contains("CUSTOMS CLEARANCE AND"))
        //                    && (dr["POD"].ToString().ToUpper().Contains("MIAMI")
        //                        || dr["POD"].ToString().ToUpper().Contains("SAN JUAN")
        //                        || dr["POD"].ToString().ToUpper().Contains("SAN ANTONIO")
        //                        || dr["POD"].ToString().ToUpper().Contains("VALPARAISO")
        //                        || dr["POD"].ToString().ToUpper().Contains("CALLAO")
        //                        || dr["POD"].ToString().ToUpper().Contains("PUERTO BARRIOS")
        //                        || dr["POD"].ToString().ToUpper().Contains("GUAYAQUIL")
        //                        || dr["POD"].ToString().ToUpper().Contains("GUATEMALA"))
        //                    )
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Does not capture LOCAL DESTINATION CHARGES OR CUSTOMS CLEARANCE ARE FOR ACCOUNT AND RISK OF CONSIGNEE 0 / 0\r\n";
        //                }
        //            }

        //        }

        //        ///Request as per Bharat Patil mail from Fri 11/29/2019 8:30 PM
        //        ///
        //        if (dr["Shipper"].ToString().Contains("DHL") && dr["Description"].ToString().Contains("EBS"))
        //        {
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "If we have DHL word in shipper then EBS word should not be in good description.\r\n";
        //        }



        //        if (dr["POD"].ToString().Trim().ToUpper().Contains("SANTOS")
        //            || dr["POD"].ToString().Trim().ToUpper().Contains("BUENOS AIRES")
        //            || dr["POD"].ToString().Trim().ToUpper().Contains("RIO GRANDE")
        //            || dr["POD"].ToString().Trim().ToUpper().Contains("RIO DE JANEIRO")
        //            || dr["POD"].ToString().Trim().ToUpper().Contains("PARANAGUA")
        //            || dr["POD"].ToString().Trim().ToUpper().Contains("ITAJAI")  ///aDDED AS PER VALIDATION # 11
        //                    )
        //        {
        //            sp_GetIATATableAdapter.Fill(sp_GetIATADataTable, dr["Freight payable at"].ToString().ToUpper());

        //            if (dr["B L No."].ToString().Substring(0, 3) == "MIL")
        //            {
        //                if (!dr["Description"].ToString().Contains("NCM"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- NCM # IS REQUIRED FOR BUENOS AIRES \r\n";
        //                }

        //                ///For MIL HS CODE was removed as per mail of Bharat Patil on Thu 12/12/2019 8:29 PM
        //                if (checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString()))
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- HS CODE Not allowed from ITALY POL to SANTOS, ITAJAI, RIO GRANDE, RIO DE JANEIRO, PARANAGUA, BUENOS AIRES \r\n";
        //            }
        //            else if (dr["B L No."].ToString().Trim().Substring(0, 3) == "PAR" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LYS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "MRS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LEH" || (sp_GetIATADataTable.Rows.Count != 0 ? !dr["FileNo"].ToString().ToUpper().Contains(sp_GetIATADataTable.Rows[0][0].ToString().ToString().ToUpper()) : false))
        //            {
        //                if (!dr["Description"].ToString().Contains("NCM") && !checkHSCODE(dr["Description"].ToString(), dr["Marks Nos"].ToString()))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- NCM # and HS CODE BOTH NOT FOUND FOR FRANCE POL TO SANTOS, ITAJAI, RIO GRANDE, RIO DE JANEIRO, PARANAGUA, BUENOS AIRES \r\n";
        //                }
        //            }
        //        }



        //        ///Validation added for ASU Port on 5 Dec 2019 by RAHUL WAGHCHAURE
        //        ///
        //        if (dr["POD"].ToString().Trim().ToUpper().Contains("ASUNCION"))
        //        {
        //            if (!dr["BL Type"].ToString().ToUpper().Contains("ORIGINAL"))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- FOR ASUNCTION POD, BILL MUST BE ORIGINAL \r\n";
        //            }

        //            if (!checkHSCODE(dr["Description"].ToString().ToUpper(), dr["Marks Nos"].ToString().ToUpper()))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- HS CODE REQUIRED FOR AUSCION\r\n";
        //            }

        //            //if ((!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("RFC")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("R.F.C")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CNPJ")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CUIT")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("VAT")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("TAX")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("USCI")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("RUC")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("ATA")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("RUT")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("NIT")
        //            //    && !dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CDMX")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("RFC")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("R.F.C")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("CNPJ")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("CUIT")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("VAT")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("TAX")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("USCI")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("RUC")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("ATA")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("RUT")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("NIT")
        //            //    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("CDMX")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("RFC")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("R.F.C")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CNPJ")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CUIT")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("VAT")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("TAX")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("USCI")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("RUC")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("ATA")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("RUT")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("NIT")
        //            //    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CDMX")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("RFC")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("R.F.C")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("CNPJ")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("CUIT")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("VAT")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("TAX")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("USCI")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("RUC")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("ATA")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("DESCONSOLIDADOR")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("RUT")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("NIT")
        //            //    && !dr["Notify"].ToString().Trim().ToUpper().Contains("CDMX")))
        //            if (!checkTAXCODE(dr["Consignee"].ToString().ToUpper(), dr["ConsigneeAddress"].ToString().ToUpper())
        //                    && !checkTAXCODE(dr["Notify"].ToString().ToUpper(), dr["NotifyAddress"].ToString().ToUpper()))
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- RUT/RUC/NIT/CUIT/RFC/TAX/VAT/CDMX/CNPJ/USCI/ATA in Consignee/notify compulsory FOR AUSNCTION \r\n";
        //            }

        //            if (p.searchdt(pdfsearchdt, "ALL LOCAL DESTINATION CHARGES") == -1)
        //            {
        //                dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE -- ALL LOCAL DESTINATION CHARGES ARE ALWAYS FOR ACCOUNT AND RISK OF CONSIGNEE \r\n";
        //            }
        //        }





        //        if (dr["B L No."].ToString().Trim().Substring(0, 3) == "ANR" || dr["B L No."].ToString().Trim().Substring(0, 3) == "PAR" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LYS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "MRS" || dr["B L No."].ToString().Trim().Substring(0, 3) == "LEH")
        //        {
        //            if (dr["POD"].ToString().Trim().ToUpper().Contains("SANTOS") || dr["POD"].ToString().Trim().ToUpper().Contains("RIO DE JANEIRO") || dr["POD"].ToString().Trim().ToUpper().Contains("RIO GRANDE") || dr["POD"].ToString().Trim().ToUpper().Contains("BUENOS AIRES"))
        //            {
        //                if (!dr["Description"].ToString().Contains("NCM") && !checkHSCODE(dr["Description"].ToString().ToUpper(), dr["Marks Nos"].ToString().ToUpper()))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- NCM # OR HS CODE should be there in GOOD DESCRIPTION for SANTOS / RIO DE JANEIRO/RIO GRANDE and BUENOS AIRES. \r\n";
        //                }
        //            }

        //            if (countryname == "BRAZIL")
        //            {
        //                //Consignee or Notify or in Goods description CNPJ no. mandatory 
        //                if (!dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                    && !dr["Consignee"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                    && !dr["Notify"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                    && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CNPJ")
        //                    && !dr["Description"].ToString().Trim().ToUpper().Contains("CNPJ"))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "CLAUSE --  CNPJ NO # is mandatory for BRAZIL Shipment\r\n";
        //                }

        //                ///Consignee-Nofity similarality check
        //                ///
        //                string clubCNEE = dr["Consignee"].ToString().Trim().ToUpper() + " " + dr["ConsigneeAddress"].ToString().Trim().ToUpper();
        //                string[] clubCNEEArray = clubCNEE.Split(' ');

        //                bool cneenotifyflag = true;
        //                foreach (string word in clubCNEEArray)
        //                {
        //                    if (!dr["NotifyAddress"].ToString().Trim().ToUpper().Contains(word.Trim()) && !dr["Notify"].ToString().Trim().ToUpper().Contains(word.Trim()))
        //                    {
        //                        cneenotifyflag = false;
        //                        break;
        //                    }
        //                }

        //                if (cneenotifyflag == true)
        //                {
        //                    if (dr["Consignee"].ToString().Trim().ToUpper().Contains("CNPJ") || dr["ConsigneeAddress"].ToString().Trim().ToUpper().Contains("CNPJ"))
        //                    {
        //                        if (!dr["Notify"].ToString().Trim().ToUpper().Contains("CNPJ") && !dr["NotifyAddress"].ToString().Trim().ToUpper().Contains("CNPJ"))
        //                        {
        //                            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- If notify is SAME AS CONSIGEE and the CNPJ number is available in the Cnee field, then it also capture in the Notify fieldS. \r\n";
        //                        }
        //                    }
        //                }
        //            }
        //            ///Added by Rahul Waghchaure on 11 Dec 2019 
        //            ///FOR MEXICO POD.
        //            ///Commented the code on request of Bharat patil on 12/12/2019
        //            //else if (countryname == "MEXICO")
        //            //{
        //            //    if (checkHSCODE(dr["Description"].ToString().ToUpper(), dr["Marks Nos"].ToString().ToUpper()))
        //            //    {
        //            //        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- HS CODE not REQUIRED. \r\n";
        //            //    }
        //            //}
        //        }



        //        if (dr["Freight Type"].ToString().ToUpper().Contains("PREPAID"))
        //        {
        //            if (dr["B L No."].ToString().Substring(0, 3) != "SIN")
        //            {
        //                if ((!dr["Freight payable at"].ToString().ToUpper().Contains(dr["POL"].ToString()) || !dr["POL"].ToString().ToUpper().Contains(dr["Freight payable at"].ToString())) && (!dr["Freight payable at"].ToString().ToUpper().Contains(dr["PLR"].ToString()) || !dr["PLR"].ToString().ToUpper().Contains(dr["Freight payable at"].ToString())))
        //                {
        //                    //  string checkport =""; dr["B L No."].ToString().Substring(0, 3);

        //                    string checkport = dr["FileNo"].ToString();
        //                    ///Temparary update by Rahul 12-23-2017
        //                    if (dr["Freight payable at"].ToString().ToUpper() == "ANTWERPEN")
        //                        dr["Freight payable at"] = "ANTWERP";

        //                    sp_GetIATATableAdapter.Fill(sp_GetIATADataTable, dr["Freight payable at"].ToString().ToUpper().Contains(",") ? dr["Freight payable at"].ToString().ToUpper().Substring(0, dr["Freight payable at"].ToString().ToUpper().IndexOf(",")) : dr["Freight payable at"].ToString().ToUpper());
        //                    if (sp_GetIATADataTable.Rows.Count != 0)
        //                    {
        //                        if (!checkport.ToUpper().Contains(sp_GetIATADataTable.Rows[0][0].ToString().ToString().ToUpper()))
        //                        {
        //                            //       dr["Freight Type"].Style.BackColor = System.Drawing.Color.Red;
        //                            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Freight payable should be POL or PLR \r\n";
        //                        }
        //                        else
        //                        {
        //                            //       dr["Freight Type"].Style.BackColor = System.Drawing.Color.Red;
        //                        }
        //                    }
        //                    else
        //                    {
        //                        //   dr["Freight Type"].Style.BackColor = System.Drawing.Color.Red;
        //                        dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Freight payable should be POL or PLR \r\n";
        //                    }
        //                }
        //            }


        //            //Ravindra # EBS word should be mention when fright term prepaid
        //            if (dr["Freight Type"].ToString().ToUpper().Contains("PREPAID"))
        //            {
        //                if ((dr["B L No."].ToString().Substring(0, 3) == "MIL"
        //                        && (dr["POD"].ToString().Trim().ToUpper().Contains("SANTOS")
        //                            || dr["POD"].ToString().Trim().ToUpper().Contains("RIO GRANDE")
        //                            || dr["POD"].ToString().Trim().ToUpper().Contains("RIO DE JANEIRO")
        //                            || dr["POD"].ToString().Trim().ToUpper().Contains("MANAUS")))
        //                        && !dr["FreightBill"].ToString().Trim().Contains("EBS")
        //                        && (!dr["Consignee"].ToString().ToUpper().Trim().Contains("DHL") && !dr["Shipper"].ToString().ToUpper().Trim().Contains("DHL")))
        //                {
        //                    dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- EBS word should be mention.\r\n";
        //                }
        //            }
        //        }
        //        else if (dr["Freight Type"].ToString().ToUpper().Contains("COLLECT") && dr["Freight payable at"].ToString().ToUpper() != "DESTINATION")
        //        {
        //            //  dr["Freight Type"].Style.BackColor = System.Drawing.Color.Red;
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- Freight payable should be DESTINATION\r\n";
        //        }

        //        if (dr["BL Type"].ToString() == "Original" && dr["Number of original Bs/L"].ToString().Contains("0"))
        //        {
        //            //   dr["BL Type"].Style.BackColor = System.Drawing.Color.Red;
        //            //   dr["Number of original Bs/L"].Style.BackColor = System.Drawing.Color.Red;
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- BL Type Original should have copies 3 / 3\r\n";
        //        }
        //        else if (dr["BL Type"].ToString() == "EXPRESS B/L" && dr["Number of original Bs/L"].ToString().Contains("3"))
        //        {
        //            //    dr["BL Type"].Style.BackColor = System.Drawing.Color.Red;
        //            //    dr["Number of original Bs/L"].Style.BackColor = System.Drawing.Color.Red;
        //            dr["ErrorDetails"] = dr["ErrorDetails"].ToString() + "General -- BL Type Express should have copies 0 / 0\r\n";
        //        }
        //        else
        //        {
        //            //   dr["POL"].Style.BackColor = System.Drawing.Color.White;
        //            //     dr["POD"].Style.BackColor = System.Drawing.Color.White;
        //        }

        //        // End of Instruction from Nilesh  Email

        //    }
        //    catch (Exception ex)
        //    {
        //        dr["ErrorDetails"] = ex.ToString() + "\n" + dr["ErrorDetails"].ToString();
        //    }
        //}

        public bool checkHSCODE(string targetstring, string secondTargetString)
        {
            List<string> includeword = new List<string> { "HS", "H.S.C", "HS CODE", "HTS CODE", "HT CODE", "HARMONIZE CODE", "HARMONIZED CODE", "CUSTOM CODE", "hs code", "HSC", "Tariff Code", "H.S", "H.S.Code", "HTS", "HTC", "CUSTOMS TARRIF" };

            if (includeword.Exists(o => secondTargetString.ToUpper().Contains(o) || targetstring.ToUpper().Contains(o)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool checkTAXCODE(string targetstring, string secondTargetString)
        {
            List<string> includeword = new List<string> { "VAT", "RUC", "TVA", "MRN", "RFC", "R.F.C", "CNPJ", "CUIT", "VAT", "TAX", "ATA", "RUT", "DESCONSOLIDADOR", "NIT", "NIF", "CDMX", "REG", "BTW", "USCI", "TVA" };

            if (includeword.Exists(o => secondTargetString.ToUpper().Contains(o) || targetstring.ToUpper().Contains(o)))
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
