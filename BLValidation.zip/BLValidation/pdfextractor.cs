﻿using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System;
using System.Collections.Generic;
using System.Text;

namespace Web.BLValidation
{
    public class pdfextractor
    {
        public string readpdf(string filename, float x1, float y1, float x2, float y2)
        {
            string currentText = "";
            try
            {
                PdfReader pdfReader = new PdfReader(filename);
                iTextSharp.text.Rectangle rect = new iTextSharp.text.Rectangle(x1, y1, x2, y2);
                RenderFilter[] renderFilter = new RenderFilter[1];
                renderFilter[0] = new RegionTextRenderFilter(rect);
                ITextExtractionStrategy textExtractionStrategy = new FilteredTextRenderListener(new LocationTextExtractionStrategy(), renderFilter);
                currentText = PdfTextExtractor.GetTextFromPage(pdfReader, 1, textExtractionStrategy);
                currentText = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(currentText)));
                pdfReader.Close();
                pdfReader.Dispose();
            }
            catch
            {
            }
            return currentText;
        }

        public string readpdf(string filename, float x1, float y1, float x2, float y2, int pageno)
        {
            string currentText = "";
            try
            {
                PdfReader pdfReader = new PdfReader(filename);
                iTextSharp.text.Rectangle rect = new iTextSharp.text.Rectangle(x1, y1, x2, y2);
                RenderFilter[] renderFilter = new RenderFilter[1];
                renderFilter[0] = new RegionTextRenderFilter(rect);
                ITextExtractionStrategy textExtractionStrategy = new FilteredTextRenderListener(new LocationTextExtractionStrategy(), renderFilter);
                ITextExtractionStrategy strategy = new SimpleTextExtractionStrategy();
                currentText = PdfTextExtractor.GetTextFromPage(pdfReader, pageno, textExtractionStrategy);
                currentText = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(currentText)));
                pdfReader.Close();
                pdfReader.Dispose();
            }
            catch (Exception ex)
            {
            }
            return currentText;
        }


        public string readpdf1(string filename, float x1, float y1, float x2, float y2, int pageno)
        {
            string currentText = "";
            try
            {
                PdfReader pdfReader = new PdfReader(filename);
                //iTextSharp.text.Rectangle rect = new iTextSharp.text.Rectangle(x1, y1, x2, y2);
                //RenderFilter[] renderFilter = new RenderFilter[1];
                //renderFilter[0] = new RegionTextRenderFilter(rect);
                //ITextExtractionStrategy textExtractionStrategy = new FilteredTextRenderListener(new LocationTextExtractionStrategy(), renderFilter);
                //ITextExtractionStrategy strategy = new SimpleTextExtractionStrategy();


                System.util.RectangleJ rect1 = new System.util.RectangleJ(x1, y1, x2, y2);
                RenderFilter[] filter = { new RegionTextRenderFilter(rect1) };
                ITextExtractionStrategy strategy1 = new FilteredTextRenderListener(
                        new LocationTextExtractionStrategy(), filter);
                currentText = PdfTextExtractor.GetTextFromPage(pdfReader, pageno, strategy1);




                //  currentText = PdfTextExtractor.GetTextFromPage(pdfReader, pageno, textExtractionStrategy);
                //  currentText = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(currentText)));
                pdfReader.Close();
                pdfReader.Dispose();
            }
            catch (Exception ex)
            {
            }
            //  return currentText.Replace("ARCHIVE COPY", "");
            return currentText;
        }


        public System.Data.DataTable searchpdf(string filepath)
        {

            System.Data.DataTable dt = new System.Data.DataTable();
            dt.Columns.Add("FieldText");
            dt.Columns.Add("XCor");
            dt.Columns.Add("YCor");
            dt.Columns.Add("PageNo");
            try
            {
                using (var r = new PdfReader(filepath))
                {
                    for (int i = 1; i <= r.NumberOfPages; i++)
                    {
                        var t = new MyLocationTextExtractionStrategy();
                        try
                        {
                            var ex = PdfTextExtractor.GetTextFromPage(r, i, t);
                        }
                        catch
                        {

                        }

                        foreach (var p in t.myPoints)
                        {
                            System.Data.DataRow dr = dt.NewRow();
                            dr["FieldText"] = p.Text;
                            dr["XCor"] = p.Rect.Left;
                            dr["YCor"] = p.Rect.Top - 15;
                            dr["PageNo"] = i;
                            dt.Rows.Add(dr);
                        }
                    }
                    r.Close();
                    r.Dispose();
                }

            }
            catch (Exception ex)
            {
                dt = searchpdf(filepath);
            }
            return dt;
        }

        public int searchdt(System.Data.DataTable dt, string[] searchstring)
        {
            int i = -1;
            foreach (System.Data.DataRow dr in dt.Rows)
            {
                foreach (string s in searchstring)
                {
                    if (dr["FieldText"].ToString().ToUpper().Contains(s.ToUpper()))
                    {
                        return dt.Rows.IndexOf(dr);
                    }
                }
            }
            return i;
        }
        public int searchdt(System.Data.DataTable dt, string searchstring)
        {
            int i = -1;

            foreach (System.Data.DataRow dr in dt.Rows)
            {
                if (dr["FieldText"].ToString().ToUpper().Contains(searchstring.ToUpper()))
                {
                    return dt.Rows.IndexOf(dr);
                }
            }

            return i;
        }
        public string searchdt_gettext(System.Data.DataTable dt, string[] searchstring, string[] defaultvalue)
        {

            foreach (System.Data.DataRow dr in dt.Rows)
            {
                foreach (string s in searchstring)
                {
                    if (dr["FieldText"].ToString().ToUpper().Contains(s.ToUpper()))
                    {
                        return defaultvalue[0].ToString();
                    }
                }
            }
            return defaultvalue[1].ToString();
        }
        public string searchdt_gettext(System.Data.DataTable dt, string[] searchstring, string defaultvalue)
        {

            foreach (System.Data.DataRow dr in dt.Rows)
            {
                foreach (string s in searchstring)
                {
                    if (dr["FieldText"].ToString().ToUpper().Contains(s.ToUpper()))
                    {
                        return s;
                    }
                }
            }
            return defaultvalue;
        }
        public class MyLocationTextExtractionStrategy : LocationTextExtractionStrategy
        {
            //Hold each coordinate
            public List<RectAndText> myPoints = new List<RectAndText>();

            //Automatically called for each chunk of text in the PDF
            public override void RenderText(TextRenderInfo renderInfo)
            {
                base.RenderText(renderInfo);

                //Get the bounding box for the chunk of text
                var bottomLeft = renderInfo.GetDescentLine().GetStartPoint();
                var topRight = renderInfo.GetAscentLine().GetEndPoint();

                //Create a rectangle from it
                var rect = new iTextSharp.text.Rectangle(
                                                        bottomLeft[Vector.I1],
                                                        bottomLeft[Vector.I2],
                                                        topRight[Vector.I1],
                                                        topRight[Vector.I2]
                                                        );

                //Add this to our main collection
                this.myPoints.Add(new RectAndText(rect, renderInfo.GetText()));
            }
        }
        public class RectAndText
        {
            public iTextSharp.text.Rectangle Rect;
            public String Text;
            public RectAndText(iTextSharp.text.Rectangle rect, String text)
            {
                this.Rect = rect;
                this.Text = text;
            }
        }
    }
}
